import React, { useEffect, useRef, useState } from 'react';
import { 
  Play, 
  RotateCcw, 
  Sliders, 
  Volume2, 
  VolumeX, 
  Trophy, 
  Clock, 
  History, 
  Settings, 
  Check, 
  Sparkles, 
  Heart, 
  ChevronRight, 
  HelpCircle,
  Undo2,
  Lock,
  ExternalLink,
  Flame,
  Palette,
  Eye,
  Github
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  SceneType, 
  GameState, 
  AssetUrls, 
  Obstacle, 
  Decoration, 
  Particle, 
  GameSettings, 
  ScoreHistory,
  PlayerSkinType,
  Collectible,
  FloatingText
} from './types';
import { 
  playJumpSound, 
  playHitSound, 
  playScoreSound, 
  startBgm, 
  stopBgm 
} from './utils/audio';
import { 
  drawPixelPlayer, 
  drawPixelObstacle, 
  drawPixelGround, 
  drawPixelCloud, 
  drawPixelMoon, 
  drawPixelHill,
  getLoadedImage
} from './utils/sprites';

// Default ImageKit or CDN Asset URL Placeholders
const DEFAULT_ASSETS: AssetUrls = {
  player: 'https://ik.imagekit.io/xxx/player.png',
  obstacle: 'https://ik.imagekit.io/xxx/obstacle.png',
  ground: 'https://ik.imagekit.io/xxx/ground.png',
  cloud: 'https://ik.imagekit.io/xxx/cloud.png',
  moon: 'https://ik.imagekit.io/xxx/moon.png',
  hill: 'https://ik.imagekit.io/xxx/hill.png'
};

const SCENE_THEMES = {
  classic: {
    bg: '#0f172a', // Slate sky
    accent: '#cbd5e1', // Slate light
    shadow: 'rgba(255,255,255,0.05)',
    glow: 'shadow-slate-500/20',
    btnActive: 'bg-slate-700 text-slate-100 border-slate-500',
    canvasBg: '#1e293b',
    border: 'border-slate-700',
    textColor: 'text-slate-300',
    themeName: '经典像素 (Classic)'
  },
  cyber: {
    bg: '#0f001c', // Ultra violet sky
    accent: '#d946ef', // Magenta neon
    shadow: 'rgba(217,70,239,0.1)',
    glow: 'shadow-fuchsia-500/30',
    btnActive: 'bg-indigo-950 text-fuchsia-400 border-fuchsia-500 shadow-[0_0_10px_rgba(217,70,239,0.3)]',
    canvasBg: '#120024',
    border: 'border-purple-800',
    textColor: 'text-purple-300',
    themeName: '赛博霓虹 (Cyber Synth)'
  },
  grass: {
    bg: '#0284c7', // Sky blue
    accent: '#22c55e', // Emerald green
    shadow: 'rgba(34,197,94,0.1)',
    glow: 'shadow-emerald-500/20',
    btnActive: 'bg-emerald-900/60 text-emerald-200 border-emerald-400',
    canvasBg: '#bae6fd',
    border: 'border-sky-300',
    textColor: 'text-sky-100',
    themeName: '草原晴空 (Sunny Grass)'
  },
  lava: {
    bg: '#180202', // Volcano black sky
    accent: '#f97316', // Orange burning magma
    shadow: 'rgba(249,115,22,0.1)',
    glow: 'shadow-orange-500/30',
    btnActive: 'bg-stone-900 text-orange-400 border-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.3)]',
    canvasBg: '#110101',
    border: 'border-red-950',
    textColor: 'text-orange-200',
    themeName: '火山废墟 (Volcano Ruins)'
  }
};

const DEFAULT_SETTINGS: GameSettings = {
  soundVolume: 0.5,
  musicVolume: 0.3,
  enableBgm: true,
  customAssets: { ...DEFAULT_ASSETS },
  playerColor: '#38bdf8', // Neon Sky Blue
  currentSkin: 'dino',
  useProceduralSprites: true,
  invincibilityMode: false,
  lowGravityMode: false
};

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  
  // React UI States
  const [gameState, setGameState] = useState<GameState>('menu');
  const [currentScene, setCurrentScene] = useState<SceneType>('classic');
  const [score, setScore] = useState<number>(0);
  const [highScore, setHighScore] = useState<number>(() => {
    return Number(localStorage.getItem('pixelRunBest') || '0');
  });
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const [showHistory, setShowHistory] = useState<boolean>(false);
  const [scoreHistory, setScoreHistory] = useState<ScoreHistory[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('pixelRunHistory') || '[]');
    } catch {
      return [];
    }
  });

  const [settings, setSettings] = useState<GameSettings>(() => {
    try {
      const saved = localStorage.getItem('pixelRunSettings');
      return saved ? { ...DEFAULT_SETTINGS, ...JSON.parse(saved) } : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  // Collectibles HUD metrics in React for absolute layout overlays
  const [coins, setCoins] = useState<number>(0);
  const [feverProgress, setFeverProgress] = useState<number>(0);
  const [feverActive, setFeverActive] = useState<boolean>(false);
  const [shieldActive, setShieldActive] = useState<boolean>(false);
  const [chiliActive, setChiliActive] = useState<boolean>(false);
  const [uiGameSpeed, setUiGameSpeed] = useState<number>(6);
  const [isPaused, setIsPaused] = useState<boolean>(false);

  // Custom Form inputs for ImageKit URLs
  const [assetInputs, setAssetInputs] = useState<AssetUrls>({ ...settings.customAssets });
  const [playerColorInput, setPlayerColorInput] = useState<string>(settings.playerColor);
  const [currentSkinInput, setCurrentSkinInput] = useState<PlayerSkinType>(settings.currentSkin);

  // Sound triggers
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Achievements State
  const [unlockedAchievements, setUnlockedAchievements] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('pixelRunAchievements') || '[]');
    } catch {
      return [];
    }
  });

  // Achievement definitions
  const achievementsList = [
    { id: 'first_run', title: '初试少年身', desc: '完成第一场跑酷', icon: '🏃' },
    { id: 'rookie_runner', title: '资深跑童', desc: '单次得分超过 80 分', icon: '⚡' },
    { id: 'pixel_adept', title: '像素达人', desc: '单次得分超过 250 分', icon: '🏆' },
    { id: 'god_mode', title: '像素之神', desc: '单次得分超过 600 分', icon: '👑' },
    { id: 'lava_master', title: '火山淬炼', desc: '在 火山废墟 场景得分超过 150 分', icon: '🔥' },
    { id: 'cyber_hacker', title: '赛博黑客', desc: '切换并体验 赛博霓虹 场景', icon: '👾' },
    { id: 'fever_disco', title: '电音狂欢客', desc: '开启狂热极速电音派对 (Fever Mode)', icon: '🪩' },
    { id: 'coin_collector', title: '黄金矿工', desc: '单场跑酷收集 20 枚黄金星币', icon: '🪙' },
  ];

  // Store game variables in refs to prevent React state lag at 60fps
  const stateRef = useRef({
    gameState: 'menu' as GameState,
    paused: false,
    pauseStartTime: 0,
    feverTimeRemaining: 0,
    chiliTimeRemaining: 0,
    score: 0,
    coins: 0,
    startTime: 0,
    gameSpeed: 6,
    playerX: 100,
    playerY: 200,
    playerSize: 32,
    playerVelocity: 0,
    gravity: 0.65,
    jumpForce: -13.5,
    isJumping: false,
    jumpCount: 0, // for double jumps
    groundY: 250,
    obstacles: [] as Obstacle[],
    decorations: [] as Decoration[],
    particles: [] as Particle[],
    collectibles: [] as Collectible[],
    floatingTexts: [] as FloatingText[],
    feverProgress: 0,
    feverActive: false,
    feverEndTime: 0,
    shieldActive: false,
    chiliActive: false,
    chiliEndTime: 0,
    collectibleIdCounter: 0,
    floatingTextIdCounter: 0,
    lastCollectibleSpawnTime: 0,
    decorationIdCounter: 0,
    scrollX: 0,
    lastObstacleTime: 0,
    lastDecorationTime: 0,
    frameCount: 0,
    lastScoreTime: 0,
    keysPressed: {} as Record<string, boolean>
  });

  // Keep ref game state in sync with React state
  useEffect(() => {
    stateRef.current.gameState = gameState;
  }, [gameState]);

  useEffect(() => {
    stateRef.current.paused = isPaused;
  }, [isPaused]);

  // Handle BGM changes
  useEffect(() => {
    if (gameState === 'playing' && settings.enableBgm && soundEnabled && !isPaused) {
      startBgm(settings.musicVolume);
    } else {
      stopBgm();
    }
    return () => {
      stopBgm();
    };
  }, [gameState, settings.enableBgm, settings.musicVolume, soundEnabled, isPaused]);

  // Persist settings
  const updateSettings = (newSettings: Partial<GameSettings>) => {
    const updated = { ...settings, ...newSettings };
    setSettings(updated);
    localStorage.setItem('pixelRunSettings', JSON.stringify(updated));
  };

  // Reset image inputs
  const handleResetAssets = () => {
    setAssetInputs({ ...DEFAULT_ASSETS });
    updateSettings({ customAssets: { ...DEFAULT_ASSETS } });
  };

  // Apply custom Settings
  const handleSaveSettings = () => {
    updateSettings({
      customAssets: assetInputs,
      playerColor: playerColorInput,
      currentSkin: currentSkinInput
    });
    setShowSettings(false);
  };

  // Game Play Logic functions
  const jumpPlayer = () => {
    const r = stateRef.current;
    if (r.paused) return;
    
    // Check gravity configuration
    const finalJumpForce = settings.lowGravityMode ? r.jumpForce * 1.25 : r.jumpForce;
    
    // Ground jump
    if (r.playerY >= r.groundY - r.playerSize) {
      r.playerVelocity = finalJumpForce;
      r.isJumping = true;
      r.jumpCount = 1;
      if (soundEnabled) playJumpSound(settings.soundVolume);
      spawnJumpRingParticle(r.playerX + r.playerSize / 2, r.playerY + r.playerSize);
    } 
    // Double jump! Up to 2 jumps allowed unless invincibility has infinite (let's do max 2)
    else if (r.jumpCount < 2) {
      r.playerVelocity = finalJumpForce * 0.9;
      r.jumpCount = 2;
      if (soundEnabled) playJumpSound(settings.soundVolume * 0.9);
      spawnJumpRingParticle(r.playerX + r.playerSize / 2, r.playerY + r.playerSize / 2);

      // Trigger floating comic comment
      const comments = ["起飞!", "翻滚!", "走你!", "双段跳!", "飞天!", "踏空!"];
      spawnFloatingText(r.playerX + r.playerSize / 2, r.playerY - 15, comments[Math.floor(Math.random() * comments.length)], '#38bdf8');
    }
  };

  // Key handlers
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const r = stateRef.current;
      
      // Toggle Pause with 'P' during play
      if (e.code === 'KeyP') {
        if (r.gameState === 'playing') {
          e.preventDefault();
          r.paused = !r.paused;
          setIsPaused(r.paused);
          
          if (r.paused) {
            // Record remaining durations
            r.pauseStartTime = Date.now();
            r.feverTimeRemaining = Math.max(0, r.feverEndTime - Date.now());
            r.chiliTimeRemaining = Math.max(0, r.chiliEndTime - Date.now());
          } else {
            // Restore timings
            const pausedDuration = Date.now() - r.pauseStartTime;
            r.startTime += pausedDuration;
            r.feverEndTime = Date.now() + r.feverTimeRemaining;
            r.chiliEndTime = Date.now() + r.chiliTimeRemaining;
          }
          
          if (soundEnabled) playScoreSound(settings.soundVolume * 0.45);
        }
        return;
      }

      // If game is paused, ignore other keys
      if (r.paused) {
        return;
      }

      // Record key pressed
      r.keysPressed[e.code] = true;

      if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
        e.preventDefault();
        if (r.gameState === 'menu') {
          startGame();
        } else if (r.gameState === 'playing') {
          jumpPlayer();
        } else if (r.gameState === 'gameover') {
          startGame();
        }
      } else if (r.gameState === 'playing') {
        if (
          e.code === 'ArrowLeft' || e.code === 'KeyA' ||
          e.code === 'ArrowRight' || e.code === 'KeyD' ||
          e.code === 'ArrowDown' || e.code === 'KeyS'
        ) {
          e.preventDefault();
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      stateRef.current.keysPressed[e.code] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [gameState, settings, soundEnabled, isPaused]);

  // Touch triggers
  const handleScreenTouch = () => {
    if (gameState === 'menu') {
      startGame();
    } else if (gameState === 'playing') {
      jumpPlayer();
    } else if (gameState === 'gameover') {
      startGame();
    }
  };

  // Triggered when starting the run
  const startGame = () => {
    const r = stateRef.current;
    r.paused = false;
    r.feverTimeRemaining = 0;
    r.chiliTimeRemaining = 0;
    r.score = 0;
    r.coins = 0;
    r.gameSpeed = currentScene === 'cyber' ? 7 : 6;
    r.playerY = 150;
    r.playerX = 100;
    r.playerVelocity = 0;
    r.keysPressed = {};
    r.isJumping = false;
    r.jumpCount = 0;
    r.obstacles = [];
    r.decorations = [];
    r.particles = [];
    r.collectibles = [];
    r.floatingTexts = [];
    r.feverProgress = 0;
    r.feverActive = false;
    r.feverEndTime = 0;
    r.shieldActive = false;
    r.chiliActive = false;
    r.chiliEndTime = 0;
    r.collectibleIdCounter = 0;
    r.floatingTextIdCounter = 0;
    r.lastCollectibleSpawnTime = 0;
    r.scrollX = 0;
    r.startTime = Date.now();
    r.lastObstacleTime = 0;
    r.lastDecorationTime = 0;
    r.frameCount = 0;
    r.lastScoreTime = Date.now();

    // Reset React UI states
    setCoins(0);
    setFeverProgress(0);
    setFeverActive(false);
    setShieldActive(false);
    setChiliActive(false);
    setUiGameSpeed(r.gameSpeed);
    setIsPaused(false);

    // Spawn starting decorations to make screen populated
    for (let i = 0; i < 4; i++) {
      spawnInitialDecoration(i * 220 + Math.random() * 50);
    }

    setScore(0);
    setGameState('playing');

    // Cyber scene unlocked trigger achievement
    if (currentScene === 'cyber') {
      unlockAchievement('cyber_hacker');
    }
  };

  const handleGameOver = () => {
    const r = stateRef.current;
    setGameState('gameover');
    if (soundEnabled) playHitSound(settings.soundVolume);

    // Save Score
    const finalScore = Math.floor(r.score / 15);
    const duration = Math.floor((Date.now() - r.startTime) / 1000);

    // Update historical runs table
    const newHistory: ScoreHistory = {
      date: new Date().toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }),
      score: finalScore,
      scene: currentScene,
      duration: isNaN(duration) ? 0 : duration
    };
    
    const updatedLogs = [newHistory, ...scoreHistory].slice(0, 8);
    setScoreHistory(updatedLogs);
    localStorage.setItem('pixelRunHistory', JSON.stringify(updatedLogs));

    // Best Score check
    if (finalScore > highScore) {
      setHighScore(finalScore);
      localStorage.setItem('pixelRunBest', String(finalScore));
    }

    // Spawn glorious crash particles
    spawnCrashExplosion(r.playerX + r.playerSize/2, r.playerY + r.playerSize/2);

    // Achievement unlocks evaluations
    unlockAchievement('first_run');
    if (finalScore >= 80) unlockAchievement('rookie_runner');
    if (finalScore >= 250) unlockAchievement('pixel_adept');
    if (finalScore >= 600) unlockAchievement('god_mode');
    if (currentScene === 'lava' && finalScore >= 150) unlockAchievement('lava_master');
    if (r.coins >= 20) unlockAchievement('coin_collector');
  };

  const unlockAchievement = (id: string) => {
    if (!unlockedAchievements.includes(id)) {
      const updated = [...unlockedAchievements, id];
      setUnlockedAchievements(updated);
      localStorage.setItem('pixelRunAchievements', JSON.stringify(updated));
    }
  };

  // Particles generator functions
  const spawnInitialDecoration = (xPos: number) => {
    const r = stateRef.current;
    const types: ('cloud' | 'hill' | 'star')[] = ['cloud', 'hill', 'star'];
    const selectedType = types[Math.floor(Math.random() * types.length)];
    
    // Ensure height ranges are pleasant
    const size = selectedType === 'cloud' ? Math.random() * 32 + 25 : Math.random() * 60 + 50;
    const yPos = selectedType === 'cloud' ? Math.random() * 70 + 15 : selectedType === 'star' ? Math.random() * 100 + 10 : r.groundY - size + 10;
    
    r.decorations.push({
      id: r.decorationIdCounter++,
      x: xPos,
      y: yPos,
      type: selectedType,
      size: size,
      speedScale: selectedType === 'star' ? 0.05 : selectedType === 'cloud' ? 0.3 : 0.6,
      w: selectedType === 'hill' ? size * 1.5 : undefined
    });
  };

  const spawnRunDust = (x: number, y: number) => {
    const r = stateRef.current;
    const count = Math.random() > 0.5 ? 2 : 1;
    for (let i = 0; i < count; i++) {
      r.particles.push({
        x: x,
        y: y + Math.random() * 4 - 2,
        vx: -(r.gameSpeed * 0.4) - Math.random() * 1.5,
        vy: -Math.random() * 1.0,
        size: Math.random() * 4 + 2,
        color: currentScene === 'lava' ? '#ef4444' : currentScene === 'cyber' ? '#d946ef' : '#94a3b8',
        alpha: 0.8,
        decay: 0.04,
        shape: 'square'
      });
    }
  };

  const spawnJumpRingParticle = (x: number, y: number) => {
    const r = stateRef.current;
    // create pixel block concentric waves
    for (let angle = 0; angle < Math.PI * 2; angle += Math.PI / 4) {
      r.particles.push({
        x: x,
        y: y,
        vx: Math.cos(angle) * 3,
        vy: Math.sin(angle) * 1.5,
        size: 5,
        color: '#ffffff',
        alpha: 1.0,
        decay: 0.06,
        shape: 'square'
      });
    }
  };

  const spawnCrashExplosion = (x: number, y: number) => {
    const r = stateRef.current;
    const count = 30;
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 7 + 3;
      r.particles.push({
        x: x,
        y: y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 2,
        size: Math.random() * 6 + 4,
        color: ['#f43f5e', '#ef4444', '#f59e0b', '#ffffaa'][Math.floor(Math.random() * 4)],
        alpha: 1.0,
        decay: 0.03,
        shape: 'square'
      });
    }
  };

  const spawnStarConfetti = (x: number, y: number, color: string) => {
    const r = stateRef.current;
    for (let i = 0; i < 8; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 4 + 1.5;
      r.particles.push({
        x: x,
        y: y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 1,
        size: Math.random() * 4 + 3,
        color: color,
        alpha: 1.0,
        decay: 0.05,
        shape: 'sparkle'
      });
    }
  };

  const spawnFloatingText = (x: number, y: number, text: string, color: string = '#ffffff') => {
    const r = stateRef.current;
    r.floatingTexts.push({
      id: r.floatingTextIdCounter++,
      x: x,
      y: y - 10,
      text: text,
      color: color,
      alpha: 1.0,
      scale: 1.0,
      vy: -1.2,
      life: 60
    });
  };

  // Main Canvas Setup Loop
  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Enable high crispness pixelated filters
    ctx.imageSmoothingEnabled = false;

    const renderLoop = () => {
      const theme = SCENE_THEMES[currentScene];
      const r = stateRef.current;
      
      if (!r.paused) {
        r.frameCount++;
      }

      // Adaptive scroll speed based on Fever and Chilli powerups
      const currentScrollSpeed = r.feverActive ? r.gameSpeed * 1.4 : (r.chiliActive ? r.gameSpeed * 1.6 : r.gameSpeed);

      // 1. Draw Canvas Sky Background (Rainbow flashing disco lights if in Fever Party!)
      if (r.feverActive) {
        const hue = (r.frameCount * 3.5) % 360;
        ctx.fillStyle = `hsl(${hue}, 40%, 14%)`;
      } else {
        ctx.fillStyle = theme.canvasBg;
      }
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Star field glow simulation specifically in cyber or space scenes (falling starry sparkles during Fever!)
      if (currentScene === 'cyber' || currentScene === 'classic' || r.feverActive) {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
        for (let i = 0; i < (r.feverActive ? 15 : 8); i++) {
          const starX = (i * 123 + r.scrollX * 0.1) % canvas.width;
          const starY = (i * 37 + (r.feverActive ? r.frameCount * 0.8 : 0)) % 130;
          ctx.fillRect(starX, starY, 2, 2);
        }
      }

      // Draw Retro Moon/Cyber Sun background element
      if (settings.useProceduralSprites) {
        // Moon size is around 40px
        drawPixelMoon(ctx, canvas.width - 150, 25, 45, currentScene);
      } else {
        const moonImg = getLoadedImage(settings.customAssets.moon);
        if (moonImg) {
          ctx.drawImage(moonImg, canvas.width - 150, 25, 45, 45);
        } else {
          drawPixelMoon(ctx, canvas.width - 150, 25, 45, currentScene);
        }
      }

      // 2. Spawn and Handle Scene Background Decorations
      if ((r.gameState === 'playing' && !r.paused) || r.gameState === 'menu') {
        const spawnDecorDelay = currentScene === 'grass' ? 85 : 140;
        if (r.frameCount - r.lastDecorationTime > spawnDecorDelay && Math.random() < 0.3) {
          // Spawn right edge
          const types: ('cloud' | 'hill')[] = ['cloud', 'hill'];
          const selectedType = types[Math.floor(Math.random() * types.length)];
          const size = selectedType === 'cloud' ? Math.random() * 32 + 25 : Math.random() * 60 + 50;
          const yPos = selectedType === 'cloud' ? Math.random() * 70 + 15 : r.groundY - size + 10;
          
          r.decorations.push({
            id: r.decorationIdCounter++,
            x: canvas.width,
            y: yPos,
            type: selectedType,
            size: size,
            speedScale: selectedType === 'cloud' ? 0.32 : 0.65,
            w: selectedType === 'hill' ? size * 1.5 : undefined
          });
          r.lastDecorationTime = r.frameCount;
        }
      }

      // Render & scroll decorations
      r.decorations.forEach(d => {
        // Scroll speed slower than ground to simulate depth parallax
        if (r.gameState === 'playing' && !r.paused) {
          d.x -= currentScrollSpeed * d.speedScale;
        }
        
        // Draw image or fallback procedurally
        if (settings.useProceduralSprites) {
          if (d.type === 'cloud') drawPixelCloud(ctx, d.x, d.y, d.size);
          if (d.type === 'hill') drawPixelHill(ctx, d.x, d.y, d.w || d.size, 60, currentScene);
        } else {
          // Attempt Image drawing
          let img: HTMLImageElement | null = null;
          if (d.type === 'cloud') img = getLoadedImage(settings.customAssets.cloud);
          if (d.type === 'all' || d.type === 'hill') img = getLoadedImage(settings.customAssets.hill);
          
          if (img) {
            ctx.drawImage(img, d.x, d.y, d.w || d.size, d.type === 'cloud' ? d.size * 0.6 : 60);
          } else {
            // fallback
            if (d.type === 'cloud') drawPixelCloud(ctx, d.x, d.y, d.size);
            if (d.type === 'hill') drawPixelHill(ctx, d.x, d.y, d.w || d.size, 60, currentScene);
          }
        }
      });
      // Filter expired decorations off the left edge
      r.decorations = r.decorations.filter(d => d.x > -200);

      // 3. Draw Beautiful Layered Soil and Floor
      if (r.gameState === 'playing' && !r.paused) {
        r.scrollX += currentScrollSpeed;
      }
      
      if (settings.useProceduralSprites) {
        drawPixelGround(ctx, canvas.width, canvas.height - r.groundY, r.groundY, r.scrollX, currentScene);
      } else {
        const groundImg = getLoadedImage(settings.customAssets.ground);
        if (groundImg) {
          // Tiles drawn scrolling
          const tileW = 120;
          const scrollOffset = r.scrollX % tileW;
          for (let tx = -tileW; tx < canvas.width + tileW; tx += tileW) {
            ctx.drawImage(groundImg, tx - scrollOffset, r.groundY, tileW, canvas.height - r.groundY);
          }
        } else {
          drawPixelGround(ctx, canvas.width, canvas.height - r.groundY, r.groundY, r.scrollX, currentScene);
        }
      }

      // -- 3A. SPAWN AND DRAW COINS AND POWER-UPS (COLLECTIBLES) --
      if (r.gameState === 'playing' && !r.paused) {
        // Collectibles spawn frequently during Fever Mode
        const spawnDelay = r.feverActive ? 22 : 95;
        if (r.frameCount - r.lastCollectibleSpawnTime > spawnDelay) {
          r.lastCollectibleSpawnTime = r.frameCount;
          
          // Spawn powerups randomly, but coins are primary
          const spawnChoice = Math.random();
          const isSpecialPowerup = spawnChoice < 0.15 && !r.feverActive;
          const spawnType = isSpecialPowerup ? (Math.random() < 0.45 ? 'shield' : 'chili') : 'coin';
          
          if (spawnType === 'coin') {
            const groupSize = r.feverActive ? 5 : Math.floor(Math.random() * 3) + 3;
            const startX = canvas.width;
            const baseHeight = r.groundY - 55 - Math.random() * 40;
            
            for (let i = 0; i < groupSize; i++) {
              let coinY = baseHeight;
              if (r.feverActive) {
                // Shiny wavy sine block during fever
                coinY = r.groundY - 85 - Math.sin((r.frameCount / 15) + i * 0.45) * 50;
              } else {
                // arced path
                coinY = baseHeight - Math.sin((i / (groupSize - 1)) * Math.PI) * 35;
              }
              
              r.collectibles.push({
                id: r.collectibleIdCounter++,
                x: startX + i * 32,
                y: coinY,
                width: 14,
                height: 14,
                type: 'coin',
                pulseFrame: Math.floor(Math.random() * 30),
                collected: false,
                value: r.feverActive ? 15 : 5
              });
            }
          } else {
            // single bubble shield or flame chili
            r.collectibles.push({
              id: r.collectibleIdCounter++,
              x: canvas.width,
              y: r.groundY - 45 - Math.random() * 25,
              width: 18,
              height: 18,
              type: spawnType,
              pulseFrame: 0,
              collected: false,
              value: 0
            });
          }
        }
      }

      // Update & Draw Collectibles
      r.collectibles.forEach(col => {
        if (r.gameState === 'playing' && !r.paused) {
          col.x -= currentScrollSpeed;

          // Magnet suction pulls coins when Fever is raging or Chilli is eaten!
          if ((r.feverActive || r.chiliActive) && col.type === 'coin' && col.x < r.playerX + 220) {
            const dx = (r.playerX + r.playerSize/2) - (col.x + col.width/2);
            const dy = (r.playerY + r.playerSize/2) - (col.y + col.height/2);
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist > 5) {
              col.x += (dx / dist) * 8.5;
              col.y += (dy / dist) * 8.5;
            }
          }
        }

        if (!col.collected) {
          // Drawing
          if (col.type === 'coin') {
            ctx.save();
            const pulse = Math.sin((r.frameCount + col.pulseFrame) * 0.18);
            const spinW = col.width * Math.abs(pulse);
            ctx.fillStyle = '#eab308'; // retro gold
            ctx.strokeStyle = '#facc15';
            ctx.lineWidth = 1.5;
            ctx.fillRect(col.x + (col.width - spinW)/2, col.y, spinW, col.height);
            ctx.strokeRect(col.x + (col.width - spinW)/2, col.y, spinW, col.height);
            // reflective white sparkles
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(col.x + col.width/2 - 1, col.y + 2, 2, 2);
            ctx.restore();
          } else if (col.type === 'shield') {
            ctx.save();
            // pulsing soft blue bubble aura
            const bubbleSize = col.width + Math.sin(r.frameCount * 0.12) * 4;
            ctx.strokeStyle = 'rgba(56, 189, 248, 0.7)';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.arc(col.x + col.width/2, col.y + col.height/2, bubbleSize/2 + 2, 0, Math.PI * 2);
            ctx.stroke();

            // inner crossbadge
            ctx.fillStyle = '#bae6fd';
            ctx.beginPath();
            ctx.arc(col.x + col.width/2, col.y + col.height/2, col.width/2 - 1, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#0284c7';
            ctx.fillRect(col.x + col.width/2 - 1, col.y + 4, 2, col.height - 8);
            ctx.fillRect(col.x + 4, col.y + col.height/2 - 1, col.width - 8, 2);
            ctx.restore();
          } else if (col.type === 'chili') {
            ctx.save();
            const scale = Math.sin(r.frameCount * 0.1) * 0.15 + 0.95;
            ctx.translate(col.x + col.width/2, col.y + col.height/2);
            ctx.scale(scale, scale);
            // Chilli body
            ctx.fillStyle = '#ef4444';
            ctx.fillRect(-5, -3, 10, 6);
            ctx.fillRect(-3, 3, 6, 4);
            ctx.fillRect(-1, 7, 2, 2);
            // Green leaf crown
            ctx.fillStyle = '#22c55e';
            ctx.fillRect(-1.5, -6, 3, 3);
            ctx.restore();
          }

          // Active Bounding collisions for pickups
          if (r.gameState === 'playing' && !r.paused) {
            const bufferCol = 2;
            const colCollideX = r.playerX + bufferCol < col.x + col.width && r.playerX + r.playerSize - bufferCol > col.x;
            const colCollideY = r.playerY + bufferCol < col.y + col.height && r.playerY + r.playerSize - bufferCol > col.y;

            if (colCollideX && colCollideY) {
              col.collected = true;
              
              if (col.type === 'coin') {
                r.coins++;
                r.score += col.value;
                if (!r.feverActive) {
                  // Increments are +4
                  r.feverProgress = Math.min(100, r.feverProgress + 4.5);
                  // Auto launch Fever Mode elements!
                  if (r.feverProgress >= 100) {
                    r.feverActive = true;
                    r.feverProgress = 100;
                    r.feverEndTime = Date.now() + 10000;
                    spawnStarConfetti(r.playerX + r.playerSize/2, r.playerY + r.playerSize/2, '#d946ef');
                    spawnFloatingText(r.playerX, r.playerY - 45, "🪩 极速电音派对 (FEVER TIME) !!", "#d946ef");
                    unlockAchievement('fever_disco');
                  }
                }
                if (soundEnabled) playScoreSound(settings.soundVolume * 0.35);
                spawnStarConfetti(col.x + col.width/2, col.y + col.height/2, '#facc15');
              } else if (col.type === 'shield') {
                r.shieldActive = true;
                if (soundEnabled) playScoreSound(settings.soundVolume * 0.9);
                spawnStarConfetti(col.x + col.width/2, col.y + col.height/2, '#38bdf8');
                spawnFloatingText(col.x, col.y, "泡泡护盾 (+SHIELD)!", "#38bdf8");
              } else if (col.type === 'chili') {
                r.chiliActive = true;
                r.chiliEndTime = Date.now() + 6000;
                if (soundEnabled) playScoreSound(settings.soundVolume * 1.25);
                spawnStarConfetti(col.x + col.width/2, col.y + col.height/2, '#f97316');
                spawnFloatingText(col.x, col.y, "爆裂辣椒 (+NITRO)!", "#f97316");
              }
            }
          }
        }
      });
      // Filter collected and off-limits
      r.collectibles = r.collectibles.filter(col => col.x > -80 && !col.collected);

      // 4. Draw Obstacles spawning physics
      if (r.gameState === 'playing' && !r.paused) {
        const minGap = 200 - Math.min(r.score * 0.05, 70); 
        const nextObsDelay = Math.random() * 80 + minGap;
        
        if (r.frameCount - r.lastObstacleTime > nextObsDelay && Math.random() < 0.015) {
          const oHeight = Math.random() * 30 + 25;
          const oWidth = 24;
          
          r.obstacles.push({
            x: canvas.width,
            y: r.groundY - oHeight,
            width: oWidth,
            height: oHeight,
            type: Math.random() > 0.75 ? 'spikes' : 'cactus',
            speedMultiplier: 1.0,
            passed: false
          });
          r.lastObstacleTime = r.frameCount;
        }
      }

      // Move & Paint obstacles
      r.obstacles.forEach(obs => {
        if (r.gameState === 'playing' && !r.paused) {
          obs.x -= currentScrollSpeed * obs.speedMultiplier;
        }

        // Draw obstacle
        if (settings.useProceduralSprites) {
          drawPixelObstacle(ctx, obs.x, obs.y, obs.width, obs.height, currentScene);
        } else {
          const obsImg = getLoadedImage(settings.customAssets.obstacle);
          if (obsImg) {
            ctx.drawImage(obsImg, obs.x, obs.y, obs.width, obs.height);
          } else {
            drawPixelObstacle(ctx, obs.x, obs.y, obs.width, obs.height, currentScene);
          }
        }

        // Check crash/collision bounding logic
        if (r.gameState === 'playing' && !r.paused) {
          const buffer = 4; // micro bounding buffer for arcade fairness
          const collideX = r.playerX + buffer < obs.x + obs.width && r.playerX + r.playerSize - buffer > obs.x;
          const collideY = r.playerY + r.playerSize - buffer > obs.y;

          if (collideX && collideY) {
            // If Nitro Spicy Chili or Fever is active, player is INVINCIBLE and smashes obstacles away!
            if (r.chiliActive || r.feverActive) {
              obs.x = -200; // crash away
              spawnCrashExplosion(r.playerX + 40, r.groundY - 15);
              spawnFloatingText(r.playerX + r.playerSize/2, r.playerY - 20, "开路撞碎! (+100)", "#fbbf24");
              r.score += 75; // Smashed score points!
              if (soundEnabled) playScoreSound(settings.soundVolume * 0.6);
            } 
            // Else if protective Bubble Shield absorbs it
            else if (r.shieldActive) {
              r.shieldActive = false;
              obs.x = -200; // crash away
              spawnCrashExplosion(r.playerX + r.playerSize/2, r.playerY + r.playerSize/2);
              spawnFloatingText(r.playerX + r.playerSize/2, r.playerY - 30, "护盾破碎 (-SHIELD)!", "#f43f5e");
              if (soundEnabled) playHitSound(settings.soundVolume * 0.45);
            } 
            else {
              if (!settings.invincibilityMode) {
                handleGameOver();
              }
            }
          }

          // Check pass/Score increment trigger
          if (!obs.passed && obs.x < r.playerX) {
            obs.passed = true;
            // Play scoring retro pop occasionally
            if (soundEnabled && Math.floor(r.score / 15) % 10 === 0) {
              playScoreSound(settings.soundVolume);
            }
          }
        }
      });
      // Exclude passed obstacles
      r.obstacles = r.obstacles.filter(obs => obs.x > -80);

      // 5. Player Physics & Jump logic
      if (r.gameState === 'playing' && !r.paused) {
        // Continuous keyboard movement control for 左右前进后退 (Left, Right, Forward, Backward)
        const moveSpeed = 5.5;
        if (r.keysPressed['ArrowLeft'] || r.keysPressed['KeyA']) {
          r.playerX = Math.max(10, r.playerX - moveSpeed);
        }
        if (r.keysPressed['ArrowRight'] || r.keysPressed['KeyD']) {
          r.playerX = Math.min(canvas.width - r.playerSize - 10, r.playerX + moveSpeed);
        }
        if (r.keysPressed['ArrowDown'] || r.keysPressed['KeyS']) {
          // Fast fall / smash down
          if (r.playerY < r.groundY - r.playerSize) {
            r.playerVelocity += 1.0; 
          }
        }

        const activeGravity = settings.lowGravityMode ? r.gravity * 0.6 : r.gravity;
        r.playerVelocity += activeGravity;
        r.playerY += r.playerVelocity;

        // Bounding top limit to prevent flying out of space bounds
        if (r.playerY < 0) {
          r.playerY = 0;
          r.playerVelocity = 0;
        }

        // Ground lock bounding
        if (r.playerY >= r.groundY - r.playerSize) {
          r.playerY = r.groundY - r.playerSize;
          r.playerVelocity = 0;
          r.isJumping = false;
          r.jumpCount = 0;
          
          // Spawn footer dust particles occasionally
          if (r.frameCount % 5 === 0) {
            spawnRunDust(r.playerX, r.groundY);
          }
        }
      }

      // Trail animations when inside Chilli or Fever
      if (r.gameState === 'playing' && !r.paused) {
        if (r.chiliActive && r.frameCount % 2 === 0) {
          // blazing hot fire trailing particles
          r.particles.push({
            x: r.playerX,
            y: r.playerY + r.playerSize/2 + Math.random() * 8 - 4,
            vx: -currentScrollSpeed * 0.45 - Math.random() * 1.5,
            vy: Math.random() * 2 - 1,
            size: Math.random() * 5 + 4,
            color: ['#ef4444', '#f97316', '#fbbf24', '#f59e0b'][Math.floor(Math.random() * 4)],
            alpha: 1.0,
            decay: 0.05,
            shape: 'square'
          });
        } else if (r.feverActive && r.frameCount % 2 === 0) {
          // neon starry tracks trailing
          r.particles.push({
            x: r.playerX,
            y: r.playerY + r.playerSize/2 + Math.random() * 8 - 4,
            vx: -currentScrollSpeed * 0.45 - Math.random() * 1.5,
            vy: Math.random() * 2 - 1,
            size: Math.random() * 6 + 3,
            color: ['#d946ef', '#a855f7', '#06b6d4', '#4ade80', '#fbbf24'][Math.floor(Math.random() * 5)],
            alpha: 1.0,
            decay: 0.04,
            shape: 'sparkle'
          });
        }
      }

      // Draw Player image/sprite with correct selected skin
      if (settings.useProceduralSprites) {
        drawPixelPlayer(ctx, r.playerX, r.playerY, r.playerSize, r.frameCount, currentScene, settings.playerColor, settings.currentSkin);
      } else {
        const playerImg = getLoadedImage(settings.customAssets.player);
        if (playerImg) {
          ctx.drawImage(playerImg, r.playerX, r.playerY, r.playerSize, r.playerSize);
        } else {
          drawPixelPlayer(ctx, r.playerX, r.playerY, r.playerSize, r.frameCount, currentScene, settings.playerColor, settings.currentSkin);
        }
      }

      // Wrap-around bubble effect if shield is active
      if (r.shieldActive) {
        ctx.save();
        const bubbleR = r.playerSize / 2 + 8 + Math.sin(r.frameCount * 0.16) * 1.8;
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.75)';
        ctx.lineWidth = 2.5;
        // glowing shield
        ctx.shadowColor = '#38bdf8';
        ctx.shadowBlur = 6;
        ctx.beginPath();
        ctx.arc(r.playerX + r.playerSize/2, r.playerY + r.playerSize/2, bubbleR, 0, Math.PI * 2);
        ctx.stroke();

        // bubble reflection sparkle
        ctx.fillStyle = 'rgba(255, 255, 255, 0.55)';
        ctx.fillRect(r.playerX + r.playerSize/2 - bubbleR/1.4, r.playerY + r.playerSize/2 - bubbleR/1.4, 3, 3);
        ctx.restore();
      }

      // Wrap-around blazing firewall if chili is active
      if (r.chiliActive) {
        ctx.save();
        const fireR = r.playerSize / 2 + 6 + Math.sin(r.frameCount * 0.22) * 2;
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.85)';
        ctx.lineWidth = 2;
        ctx.shadowColor = '#f97316';
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.arc(r.playerX + r.playerSize/2, r.playerY + r.playerSize/2, fireR, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }

      // Timer cooling down checks
      if (r.gameState === 'playing' && !r.paused) {
        if (r.feverActive && Date.now() > r.feverEndTime) {
          r.feverActive = false;
          r.feverProgress = 0;
          spawnFloatingText(r.playerX, r.playerY - 45, "派对落幕...", "#94a3b8");
        }
        if (r.chiliActive && Date.now() > r.chiliEndTime) {
          r.chiliActive = false;
          spawnFloatingText(r.playerX, r.playerY - 45, "辣椒冷却~", "#94a3b8");
        }
      }

      // 6. Handle Retro Particles (with advanced shapes like star sparks and shield bubble outlines)
      r.particles.forEach(p => {
        if (!r.paused) {
          p.x += p.vx;
          p.y += p.vy;
          p.alpha -= p.decay;
        }
        
        ctx.save();
        ctx.globalAlpha = Math.max(p.alpha, 0);
        ctx.fillStyle = p.color;
        
        if (p.shape === 'square') {
          ctx.fillRect(p.x, p.y, p.size, p.size);
        } else if (p.shape === 'sparkle') {
          // Quad cross-star retro spark
          ctx.fillRect(p.x - p.size/2, p.y - 1, p.size, 2);
          ctx.fillRect(p.x - 1, p.y - p.size/2, 2, p.size);
          // core shiny white
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(p.x - 1, p.y - 1, 2, 2);
        } else if (p.shape === 'bubble') {
          ctx.strokeStyle = p.color;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size/2, 0, Math.PI * 2);
          ctx.stroke();
        } else {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size/2, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      });
      r.particles = r.particles.filter(p => p.alpha > 0);

      // Render & Float comic floating text labels
      r.floatingTexts.forEach(t => {
        if (!r.paused) {
          t.y += t.vy;
          t.life--;
          t.alpha = Math.max(0, t.life / 60);
        }

        ctx.save();
        ctx.globalAlpha = t.alpha;
        ctx.font = 'bold 9px font-mono, monospace, Courier';
        ctx.textAlign = 'center';

        // Shadows
        ctx.fillStyle = '#000000';
        ctx.fillText(t.text, t.x - 1, t.y + 1);
        ctx.fillText(t.text, t.x + 1, t.y + 1);
        ctx.fillText(t.text, t.x - 1, t.y - 1);
        ctx.fillText(t.text, t.x + 1, t.y - 1);

        // Core fill text
        ctx.fillStyle = t.color;
        ctx.fillText(t.text, t.x, t.y);
        ctx.restore();
      });
      r.floatingTexts = r.floatingTexts.filter(t => t.life > 0);

      // 7. Update Score Display multiplier (score 3x faster in Fever and 2x faster in chili nitro!)
      if (r.gameState === 'playing' && !r.paused) {
        const rate = r.feverActive ? 4.5 : (r.chiliActive ? 3.0 : 1.5);
        r.score += rate;
        const currentProgress = Math.floor(r.score / 15);
        setScore(currentProgress);

        // Periodically increase speed multiplier gently
        if (currentProgress > 0 && currentProgress % 100 === 0 && r.frameCount % 10 === 0) {
          r.gameSpeed += 0.08;
        }
      }

      // Throttled Propagation back to React (keeps game at buttery smooth 60fps)
      if (r.frameCount % 5 === 0) {
        setCoins(r.coins);
        setFeverProgress(Math.floor(r.feverProgress));
        setFeverActive(r.feverActive);
        setShieldActive(r.shieldActive);
        setChiliActive(r.chiliActive);
        setUiGameSpeed(r.gameSpeed);
      }

      // Keep animation looping
      animId = requestAnimationFrame(renderLoop);
    };

    renderLoop();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [currentScene, settings, soundEnabled]);

  // Handle Scene and trigger background changes
  const handleSceneSelect = (scene: SceneType) => {
    setCurrentScene(scene);
    // Restart logic keeps it clean
    if (gameState === 'playing') {
      startGame();
    }
  };

  return (
    <div className="min-h-screen font-mono text-slate-100 flex flex-col items-center justify-between transition-colors duration-500 py-4 px-4 select-none relative overflow-x-hidden"
         style={{ backgroundColor: SCENE_THEMES[currentScene].bg }}>
         
      {/* Background Neon Grid Accent Lines specifically on Lava or Cyber scenes */}
      {currentScene === 'cyber' && (
        <div className="absolute inset-x-0 bottom-0 top-[20%] bg-[linear-gradient(rgba(217,70,239,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(217,70,239,0.05)_1px,transparent_1px)] bg-[size:30px_30px] pointer-events-none" />
      )}
      {currentScene === 'lava' && (
        <div className="absolute inset-0 bg-radial-at-b from-red-950/20 via-transparent to-transparent pointer-events-none" />
      )}

      {/* Top Header section holding score boards and controller options */}
      <header className="w-full max-w-4xl flex items-center justify-between gap-4 z-10 flex-wrap shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-black/40 border border-slate-700/60 flex items-center justify-center animate-pulse">
            <span className="text-xl">🏃</span>
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              像素跑酷 <span className="text-xs font-mono uppercase px-2 py-0.5 bg-rose-500/20 text-rose-300 rounded border border-rose-500/30">最终完整版</span>
            </h1>
            <p className="text-[10px] text-slate-400">Pristine 8-Bit Retro Run Frame Simulator</p>
          </div>
        </div>

        {/* Current Score displays */}
        <div className="flex items-center gap-4 bg-black/50 border border-slate-800/80 px-4 py-2 rounded-xl backdrop-blur-sm shadow-xl relative overflow-hidden group">
          <div className="absolute -inset-x-2 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-[1200ms] ease-out-sine" />
          <div className="text-center min-w-[70px]">
            <p className="text-[10px] uppercase tracking-wider text-slate-400 font-mono">分数 (Score)</p>
            <p className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">
              {score}
            </p>
          </div>
          <div className="w-[1px] h-8 bg-slate-800" />
          <div className="text-center min-w-[80px]" id="best-score-display">
            <p className="text-[10px] uppercase tracking-wider text-slate-400 flex items-center justify-center gap-1">
              <Trophy className="w-3 h-3 text-yellow-400" /> 最高分
            </p>
            <p className="text-2xl font-bold font-mono text-yellow-400 tabular-nums">
              {highScore}
            </p>
          </div>
        </div>
      </header>

      {/* Scene and level environment selector */}
      <div className="w-full max-w-4xl my-3 z-10">
        <div className="bg-black/40 border border-slate-800/60 p-2 rounded-2xl backdrop-blur-md shadow-2xl flex flex-wrap items-center justify-between gap-3 gap-y-2">
          <span className="text-xs px-2 text-slate-300 font-semibold flex items-center gap-1.5 shrink-0">
            <Palette className="w-4 h-4 text-cyan-400" /> 场景切换 (Levels):
          </span>
          <div className="flex flex-wrap items-center gap-2">
            {(Object.keys(SCENE_THEMES) as SceneType[]).map((sceneKey) => {
              const active = currentScene === sceneKey;
              return (
                <button
                  key={sceneKey}
                  id={`scene-${sceneKey}`}
                  onClick={() => handleSceneSelect(sceneKey)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wide border transition-all duration-300 ${
                    active 
                      ? SCENE_THEMES[sceneKey].btnActive 
                      : 'bg-black/30 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-slate-200'
                  }`}
                >
                  {sceneKey === 'classic' && '🌑 经典像素'}
                  {sceneKey === 'cyber' && '🔮 赛博霓虹'}
                  {sceneKey === 'grass' && '☀️ 草原晴空'}
                  {sceneKey === 'lava' && '🔥 火山废墟'}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Game Interface Board Area */}
      <main className="w-full max-w-4xl flex-grow flex flex-col justify-center my-1 z-10">
        <div className="relative rounded-2xl overflow-hidden shadow-2xl border-4 border-slate-800 max-h-[350px] group transition-all duration-300"
             style={{ 
               borderColor: SCENE_THEMES[currentScene].accent,
               boxShadow: `0 25px 50px -12px ${SCENE_THEMES[currentScene].shadow}`
             }}>
          
          {/* Game Canvas Board */}
          <canvas
            ref={canvasRef}
            id="gameCanvas"
            width={800}
            height={300}
            onClick={gameState === 'playing' ? jumpPlayer : handleScreenTouch}
            className="w-full h-auto block cursor-pointer object-cover aspect-[8/3] max-h-[300px]"
            style={{ imageRendering: 'pixelated' }}
          />

          {/* Active Run HUD Indicators */}
          {gameState === 'playing' && (
            <div className="absolute inset-0 pointer-events-none p-3.5 flex flex-col justify-between font-mono select-none">
              {/* TOP ROW */}
              <div className="flex justify-between items-start w-full gap-2 text-[10px]">
                
                {/* 1. Star Coin Counter */}
                <div className="flex items-center gap-1.5 bg-black/60 border border-yellow-500/30 px-3 py-1.5 rounded-xl backdrop-blur-md shadow-lg">
                  <span className="text-sm animate-pulse">🪙</span>
                  <div className="text-left">
                    <p className="text-[8px] text-slate-400 uppercase leading-none">星星金币</p>
                    <p className="text-xs font-black text-yellow-500 tabular-nums leading-none mt-0.5">{coins}</p>
                  </div>
                </div>

                {/* 2. Speed Control Meter */}
                <div className="flex items-center gap-1.5 bg-black/60 border border-emerald-500/30 px-3 py-1.5 rounded-xl backdrop-blur-md shadow-lg">
                  <span className="text-sm">⚡</span>
                  <div className="text-left">
                    <p className="text-[8px] text-slate-400 uppercase leading-none font-bold">引擎跑速</p>
                    <p className="text-xs font-black text-emerald-400 tabular-nums leading-none mt-0.5">{uiGameSpeed.toFixed(1)}x</p>
                  </div>
                </div>

                {/* 3. Fever Charging Battery */}
                <div className="flex flex-col items-center bg-black/60 border border-fuchsia-500/20 px-4 py-1.5 rounded-xl backdrop-blur-md shadow-lg max-w-[155px] w-full">
                  <div className="flex justify-between items-center w-full mb-1">
                    <span className="text-[8px] text-slate-400 uppercase leading-none font-bold">
                      {feverActive ? '🪩 FEVER PARTY!' : '⚡ FEVER 能量'}
                    </span>
                    <span className={`text-[8px] font-extrabold ${feverActive ? 'text-fuchsia-400 animate-pulse' : 'text-slate-300'}`}>
                      {feverActive ? 'MAX' : `${feverProgress}%`}
                    </span>
                  </div>
                  {/* Energy bar slot */}
                  <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                    <div 
                      className={`h-full rounded-full transition-all duration-300 ${
                        feverActive 
                          ? 'bg-gradient-to-r from-fuchsia-500 via-pink-400 to-indigo-400 animate-pulse w-full' 
                          : 'bg-emerald-400'
                      }`}
                      style={{ width: feverActive ? '100%' : `${feverProgress}%` }}
                    />
                  </div>
                </div>

                {/* 4. Active Buff Perks */}
                <div className="flex items-center gap-1.5">
                  {shieldActive && (
                    <div className="flex items-center justify-center p-2 rounded-xl bg-sky-950/80 border border-sky-400/50 backdrop-blur-md shadow-[0_0_8px_rgba(56,189,248,0.4)] animate-pulse">
                      <span className="text-xs">🛡️</span>
                    </div>
                  )}
                  {chiliActive && (
                    <div className="flex items-center justify-center p-2 rounded-xl bg-rose-950/80 border border-rose-400/50 backdrop-blur-md shadow-[0_0_8px_rgba(244,63,94,0.4)] animate-pulse">
                      <span className="text-xs">🔥</span>
                    </div>
                  )}
                </div>
              </div>

              {/* BOTTOM ROW (Controls Info hints if needed, or empty space) */}
              <div className="flex justify-between w-full items-end mt-auto gap-2">
                <span className="text-[8px] text-slate-400 bg-black/60 border border-slate-800/40 px-2 py-0.5 rounded-md">Space / ↑ / W 触发跳跃 & 双段跳 | A / D / ← / → 自由移动与下落</span>
                {feverActive && (
                  <span className="text-[9px] text-fuchsia-300 font-extrabold animate-pulse bg-fuchsia-950/60 border border-fuchsia-500/30 px-2.5 py-0.5 rounded-full">
                    🎉 分数 3 倍狂飙中!
                  </span>
                )}
                {chiliActive && !feverActive && (
                  <span className="text-[9px] text-orange-300 font-extrabold animate-pulse bg-rose-950/60 border border-rose-500/30 px-2.5 py-0.5 rounded-full">
                    🚀 狠辣狂飙 2 倍分速中!
                  </span>
                )}
              </div>
            </div>
          )}

          {/* Canvas state overlays */}
          
          {/* OVERLAY 1: Startup Menu */}
          <AnimatePresence>
            {gameState === 'menu' && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-black/75 flex flex-col items-center justify-center p-6 text-center backdrop-blur-xs select-none"
              >
                <div className="max-w-md">
                  <motion.div
                    initial={{ scale: 0.8, y: 15 }}
                    animate={{ scale: 1, y: 0 }}
                    transition={{ type: "spring", stiffness: 100 }}
                  >
                    <span className="text-3xl inline-block mb-3 animate-bounce">🦖</span>
                    <h2 className="text-3xl font-extrabold tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-sky-400 to-indigo-400 uppercase">
                      像素跑酷
                    </h2>
                    <p className="text-xs text-slate-400 mt-1.5 px-4 font-mono leading-relaxed">
                      像素级别的纯正手感：避开重重障碍，向着更高分极速狂奔！支持空中连续双段跳跃！
                    </p>
                  </motion.div>

                  <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-3">
                    <button
                      id="start-game-button"
                      onClick={startGame}
                      className="px-6 py-3 w-full sm:w-auto rounded-xl font-bold bg-white text-black hover:bg-emerald-400 hover:text-black shadow-lg shadow-white/10 active:scale-95 transition-all text-sm uppercase flex items-center justify-center gap-2 border border-white"
                    >
                      <Play className="w-5 h-5 fill-current" /> 开始跑酷 (Space)
                    </button>
                    <button
                      id="open-settings-button"
                      onClick={() => setShowSettings(true)}
                      className="px-5 py-3 w-full sm:w-auto rounded-xl font-bold bg-slate-900 border border-slate-700 hover:border-slate-500 hover:bg-slate-800 transition-all text-sm flex items-center justify-center gap-2"
                    >
                      <Settings className="w-4 h-4" /> 自定义设置
                    </button>
                  </div>

                  <div className="mt-5 p-2 px-3 rounded-lg border border-slate-800 bg-slate-950/60 font-mono text-[10px] text-slate-400 flex flex-col gap-1 inline-block mx-auto">
                    <div className="flex justify-center gap-3">
                      <span>跳跃: <kbd className="px-1.5 py-0.5 bg-slate-900 border border-slate-800 rounded text-slate-300 font-sans font-bold">Space</kbd> / <kbd className="px-1.5 py-0.5 bg-slate-900 border border-slate-800 rounded text-slate-300 font-sans font-bold">W</kbd> / <kbd className="px-1.5 py-0.5 bg-slate-900 border border-slate-800 rounded text-slate-300 font-sans font-bold">↑</kbd></span>
                      <span>下坠: <kbd className="px-1.5 py-0.5 bg-slate-900 border border-slate-800 rounded text-slate-300 font-sans font-bold">S</kbd> / <kbd className="px-1.5 py-0.5 bg-slate-900 border border-slate-800 rounded text-slate-300 font-sans font-bold">↓</kbd></span>
                    </div>
                    <div className="flex justify-center gap-3 border-t border-slate-900 pt-1 mt-1">
                      <span>后退: <kbd className="px-1.5 py-0.5 bg-slate-900 border border-slate-800 rounded text-slate-300 font-sans font-bold">A</kbd> / <kbd className="px-1.5 py-0.5 bg-slate-900 border border-slate-800 rounded text-slate-300 font-sans font-bold">←</kbd></span>
                      <span>前进: <kbd className="px-1.5 py-0.5 bg-slate-900 border border-slate-800 rounded text-slate-300 font-sans font-bold">D</kbd> / <kbd className="px-1.5 py-0.5 bg-slate-900 border border-slate-800 rounded text-slate-300 font-sans font-bold">→</kbd></span>
                      <span>暂停: <kbd className="px-1.5 py-0.5 bg-slate-900 border border-slate-800 rounded text-slate-300 font-sans font-bold">P</kbd></span>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* OVERLAY 3: Paused Screen Overlay */}
          <AnimatePresence>
            {gameState === 'playing' && isPaused && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center p-6 text-center backdrop-blur-xs select-none z-20"
              >
                <div className="max-w-md">
                  <motion.div
                    initial={{ scale: 0.85, y: 10 }}
                    animate={{ scale: 1, y: 0 }}
                    exit={{ scale: 0.85, y: 10 }}
                    transition={{ type: "spring", stiffness: 110 }}
                    className="bg-slate-900/95 border-2 border-slate-700/80 p-5 rounded-2xl shadow-[0_0_30px_rgba(0,0,0,0.95)] backdrop-blur-md"
                  >
                    <div className="w-12 h-12 rounded-full bg-cyan-500/15 border border-cyan-400/30 flex items-center justify-center mx-auto mb-3">
                      <span className="text-xl animate-pulse font-sans font-bold text-cyan-400">‖</span>
                    </div>
                    
                    <h2 className="text-2xl font-black tracking-widest text-[#22d3ee] uppercase font-mono animate-pulse">
                      游戏已暂停
                    </h2>
                    
                    <div className="mt-4 py-2 border-y border-slate-800/80 flex justify-center gap-6 text-xs text-slate-400 font-mono">
                      <div>
                        <span className="block text-[10px] text-slate-500">当前分数</span>
                        <span className="text-base font-bold text-emerald-400">{score}</span>
                      </div>
                      <div className="w-[1px] bg-slate-800" />
                      <div>
                        <span className="block text-[10px] text-slate-500">累计金币</span>
                        <span className="text-base font-bold text-yellow-500">{coins}</span>
                      </div>
                    </div>

                    <div className="mt-5 flex flex-col sm:flex-row gap-2.5 justify-center">
                      <button
                        onClick={() => {
                          const r = stateRef.current;
                          r.paused = false;
                          setIsPaused(false);
                          
                          // Restore timings
                          const pausedDuration = Date.now() - r.pauseStartTime;
                          r.startTime += pausedDuration;
                          r.feverEndTime = Date.now() + r.feverTimeRemaining;
                          r.chiliEndTime = Date.now() + r.chiliTimeRemaining;
                          
                          if (settings.enableBgm && soundEnabled) {
                            startBgm(settings.musicVolume);
                          }
                          
                          if (soundEnabled) playScoreSound(settings.soundVolume * 0.4);
                        }}
                        className="px-5 py-2.5 rounded-xl text-xs font-bold bg-cyan-400 text-black hover:bg-cyan-300 transition-all active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer border border-cyan-300"
                      >
                        继续游戏 (P)
                      </button>
                      <button
                        onClick={startGame}
                        className="px-5 py-2.5 rounded-xl text-xs font-bold bg-slate-800 border border-slate-700 text-slate-200 hover:bg-slate-750 transition-all active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5" /> 重新开始
                      </button>
                    </div>

                    <p className="text-[9px] text-slate-500 mt-4 leading-none select-none">
                      按快捷键 <kbd className="px-1.5 py-0.5 bg-black border border-slate-800 rounded text-slate-400 text-[10px] font-sans font-bold">P</kbd> 可快速恢复
                    </p>
                  </motion.div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* OVERLAY 2: Game Over Screen with Smooth Fade Transition */}
          <AnimatePresence>
            {gameState === 'gameover' && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.4 }}
                className="absolute inset-0 bg-red-950/85 flex flex-col items-center justify-center p-6 text-center backdrop-blur-xs select-none"
              >
                <div className="max-w-md">
                  <motion.div
                    initial={{ y: 20, scale: 0.9 }}
                    animate={{ y: 0, scale: 1 }}
                    transition={{ type: "spring", stiffness: 120, delay: 0.1 }}
                  >
                    <div className="w-14 h-14 rounded-full bg-red-600/20 border border-red-500/40 flex items-center justify-center mx-auto mb-3 animate-pulse">
                      <Flame className="w-8 h-8 text-red-500" />
                    </div>
                    <h2 className="text-2xl sm:text-3xl font-extrabold uppercase text-rose-500 tracking-widest leading-none">
                      游戏结束 (Crash)
                    </h2>
                    <p className="text-xs text-red-300 mt-2">
                      挑战在突如其来的巨石面前戛然而止！
                    </p>
                  </motion.div>

                  {/* Summary performance stats block */}
                  <div className="mt-5 grid grid-cols-2 gap-3 max-w-xs mx-auto">
                    <div className="bg-black/60 p-3 rounded-xl border border-red-900/40">
                      <p className="text-[9px] uppercase tracking-wider text-slate-400">本次得分</p>
                      <p className="text-lg font-bold text-red-400">{score}</p>
                    </div>
                    <div className="bg-black/60 p-3 rounded-xl border border-red-900/40">
                      <p className="text-[9px] uppercase tracking-wider text-slate-400">历史最高</p>
                      <p className="text-lg font-bold text-yellow-400">{highScore}</p>
                    </div>
                  </div>

                  {/* Operational re-action button */}
                  <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-3">
                    <button
                      id="restart-button"
                      onClick={startGame}
                      className="px-6 py-2.5 w-full sm:w-auto rounded-xl font-bold bg-white text-black hover:bg-emerald-400 hover:text-black shadow-lg hover:shadow-emerald-500/20 active:scale-95 transition-all text-xs uppercase flex items-center justify-center gap-2"
                    >
                      <RotateCcw className="w-4 h-4" /> 重新开始 (Space)
                    </button>
                    <button
                      id="change-theme-quick-button"
                      onClick={() => {
                        const scenesArray: SceneType[] = ['classic', 'cyber', 'grass', 'lava'];
                        const nextIdx = (scenesArray.indexOf(currentScene) + 1) % scenesArray.length;
                        handleSceneSelect(scenesArray[nextIdx]);
                      }}
                      className="px-5 py-2.5 w-full sm:w-auto rounded-xl font-bold bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs flex items-center justify-center gap-2 transition-all"
                    >
                      <Palette className="w-4 h-4" /> 换个场景
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Mobile touch active padding control HUD helper */}
        <div className="flex sm:hidden mt-2 select-none gap-2">
          <button
            onClick={handleScreenTouch}
            className="flex-grow py-5 bg-white/10 active:bg-white/20 border border-slate-700 active:border-cyan-400 text-white font-extrabold uppercase rounded-xl tracking-wider text-sm flex items-center justify-center gap-2 transition-all h-20"
          >
            🔊 点击此区触发跳跃 / DOUBLE JUMP
          </button>
        </div>
      </main>

      {/* Grid containing Achievements panel and Score Log History */}
      <section className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-12 gap-4 mt-2 z-10 shrink-0">
        
        {/* Run history records left column */}
        <div className="md:col-span-7 bg-black/40 border border-slate-800/60 p-4 rounded-2xl backdrop-blur-md flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3 border-b border-slate-800/80 pb-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <History className="w-4 h-4 text-emerald-400" /> 跑酷历史记录 (Runs Log)
              </h3>
              <button
                id="clear-logs-btn"
                onClick={() => {
                  setScoreHistory([]);
                  localStorage.removeItem('pixelRunHistory');
                }}
                className="text-[9px] text-slate-500 hover:text-red-400 transition-colors uppercase shrink-0"
              >
                清空记录
              </button>
            </div>

            {scoreHistory.length === 0 ? (
              <div className="py-6 text-center text-slate-500">
                <p className="text-xs">暂无历史跑酷记录，快去开启你的第一场狂奔吧！</p>
              </div>
            ) : (
              <div className="space-y-2 overflow-y-auto max-h-[140px] pr-1 scrollbar-thin">
                {scoreHistory.map((log, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-black/40 border border-slate-800/50 rounded-lg text-xs hover:border-slate-700 hover:bg-black/60 transition-all">
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-slate-500 text-[10px] w-4">#{scoreHistory.length - index}</span>
                      <div className="text-left">
                        <p className="font-bold text-slate-200">得分: {log.score}</p>
                        <p className="text-[9px] text-slate-500 flex items-center gap-1">
                          <Clock className="w-2.5 h-2.5" /> 耗时: {log.duration}s | 场景: {
                            log.scene === 'classic' ? '经典' :
                            log.scene === 'cyber' ? '霓虹' :
                            log.scene === 'grass' ? '草原' : '火山'
                          }
                        </p>
                      </div>
                    </div>
                    <span className="text-[10px] text-slate-400 bg-slate-900 border border-slate-800 px-2 py-0.5 rounded font-mono">
                      {log.date}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="mt-3 pt-2 text-[10px] text-slate-500 border-t border-slate-900 flex items-center justify-between">
            <span>双段跳机制: 起跳后再按一次 Space 可触发空翻回旋加速跳。</span>
            <span className="text-emerald-400 font-semibold">100% 离线完美运行</span>
          </div>
        </div>

        {/* Achievements list right column */}
        <div className="md:col-span-5 bg-black/40 border border-slate-800/60 p-4 rounded-2xl backdrop-blur-md">
          <div className="flex items-center justify-between mb-3 border-b border-slate-800/80 pb-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-yellow-400 animate-spin-slow" /> 奖杯荣誉板 ({unlockedAchievements.length} / {achievementsList.length})
            </h3>
            {unlockedAchievements.length === achievementsList.length && (
              <span className="text-[8px] uppercase tracking-widest text-yellow-300 bg-yellow-500/20 border border-yellow-500/40 px-1.5 py-0.5 rounded font-bold animate-pulse">
                满贯
              </span>
            )}
          </div>

          <div className="space-y-1.5 max-h-[140px] overflow-y-auto pr-1">
            {achievementsList.map((ach) => {
              const isLocked = !unlockedAchievements.includes(ach.id);
              return (
                <div 
                  key={ach.id} 
                  className={`flex items-start gap-2.5 p-1.5 rounded-lg border transition-all text-left ${
                    isLocked 
                      ? 'bg-black/20 border-slate-950 opacity-40' 
                      : 'bg-yellow-950/20 border-yellow-900/30 hover:border-yellow-700/40'
                  }`}
                >
                  <span className="text-base select-none">{isLocked ? '🔒' : ach.icon}</span>
                  <div className="min-w-0">
                    <p className={`text-xs font-semibold ${isLocked ? 'text-slate-500 line-through' : 'text-yellow-400'}`}>
                      {ach.title}
                    </p>
                    <p className="text-[9px] text-slate-400 truncate leading-normal">{ach.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Main Bottom operational utility buttons */}
      <footer className="w-full max-w-4xl flex items-center justify-between mt-4 text-[11px] text-slate-500 gap-4 z-10 shrink-0 border-t border-slate-800/60 pt-3 flex-wrap">
        <div className="flex items-center gap-3">
          <button
            id="audio-config-toggle"
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="flex items-center gap-1.5 text-slate-400 hover:text-white transition-colors cursor-pointer bg-slate-900/60 hover:bg-slate-800 border border-slate-800/80 px-2.5 py-1.5 rounded-lg"
          >
            {soundEnabled ? (
              <>
                <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>音效: 开启</span>
              </>
            ) : (
              <>
                <VolumeX className="w-3.5 h-3.5 text-rose-400" />
                <span>音效: 关闭</span>
              </>
            )}
          </button>
          
          <button
            id="bgm-config-toggle"
            onClick={() => updateSettings({ enableBgm: !settings.enableBgm })}
            className={`flex items-center gap-1.5 text-slate-400 hover:text-white transition-colors cursor-pointer border px-2.5 py-1.5 rounded-lg ${
              settings.enableBgm ? 'bg-indigo-950/40 border-indigo-900/60' : 'bg-slate-900/60 border-slate-800/80'
            }`}
          >
            <span>🎸 8-Bit BGM: {settings.enableBgm ? '开启' : '关闭'}</span>
          </button>
        </div>

        <div className="flex items-center gap-3">
          <button
            id="open-settings-fab"
            onClick={() => {
              setAssetInputs({ ...settings.customAssets });
              setShowSettings(true);
            }}
            className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 transition-colors uppercase cursor-pointer"
          >
            <Sliders className="w-3 h-3" /> 像素素材配置/ImageKit
          </button>
        </div>
      </footer>

      {/* MODAL WINDOW 1: Custom Settings & ImageKit Manager */}
      <AnimatePresence>
        {showSettings && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/85 flex items-center justify-center p-4 z-50 backdrop-blur-md"
          >
            <motion.div 
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-slate-900 border border-slate-850 w-full max-w-2xl rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
            >
              <div className="bg-slate-950 p-4 border-b border-slate-800/80 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-cyan-400" />
                  <h3 className="font-bold text-white text-sm">ImageKit 素材链接 & 玩法设置</h3>
                </div>
                <button
                  id="close-settings-cross"
                  onClick={() => setShowSettings(false)}
                  className="text-slate-400 hover:text-white text-sm p-1"
                >
                  ✕
                </button>
              </div>

              {/* Scrollable Form parameters */}
              <div className="p-5 overflow-y-auto space-y-4 max-h-[calc(90vh-120px)] text-left font-sans text-xs">
                
                {/* 1. Rendering engine setting */}
                <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/40">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-slate-100 flex items-center gap-1 text-sm font-mono leading-none">
                        ⚙️ 绘制模式 选择
                      </p>
                      <p className="text-[10px] text-slate-400 leading-wide mt-1">
                        开启后将默认展示我们为您高级定制的 16x16 极速 procedural 经典像素板绘，流畅度翻倍！
                      </p>
                    </div>
                    <button
                      id="toggle-procedural-sprites"
                      onClick={() => updateSettings({ useProceduralSprites: !settings.useProceduralSprites })}
                      className={`px-3 py-1.5 rounded-lg font-bold font-mono transition-all border ${
                        settings.useProceduralSprites
                          ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                          : 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
                      }`}
                    >
                      {settings.useProceduralSprites ? '🎨 预装像素板绘' : '🖼️ 自定义 URL 渲染'}
                    </button>
                  </div>
                </div>

                {/* 2. ImageKit URLs Replacement Inputs */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                    <p className="font-semibold text-slate-100 text-[13px] flex items-center gap-1.5">
                      🖼️ ImageKit 素材资源链接配置
                    </p>
                    <button
                      id="reset-assets-defaults-btn"
                      onClick={handleResetAssets}
                      className="text-[10px] text-yellow-400 hover:text-yellow-300 font-mono"
                    >
                      (重置所有输入至占位符)
                    </button>
                  </div>
                  <p className="text-[10px] text-slate-400 leading-relaxed font-mono">
                    说明：在下方输入您在 ImageKit 上传的 CDN 链接，关闭 “预装像素板绘” 后，游戏将自动从下方链接实时获取图片并渲染！
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono">
                    {/* Character/Player */}
                    <div>
                      <label className="block text-[11px] text-slate-300 mb-1">🦖 玩家像素图 (Player.png)</label>
                      <input
                        type="text"
                        value={assetInputs.player}
                        onChange={(e) => setAssetInputs({ ...assetInputs, player: e.target.value })}
                        disabled={settings.useProceduralSprites}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-slate-300 text-xs focus:border-cyan-400 outline-none disabled:opacity-40 transition-all font-mono"
                      />
                    </div>

                    {/* Obstacle */}
                    <div>
                      <label className="block text-[11px] text-slate-300 mb-1">🌵 障碍物像素图 (Obstacle.png)</label>
                      <input
                        type="text"
                        value={assetInputs.obstacle}
                        onChange={(e) => setAssetInputs({ ...assetInputs, obstacle: e.target.value })}
                        disabled={settings.useProceduralSprites}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-slate-300 text-xs focus:border-cyan-400 outline-none disabled:opacity-40 transition-all font-mono"
                      />
                    </div>

                    {/* Ground */}
                    <div>
                      <label className="block text-[11px] text-slate-300 mb-1">🧱 地面循环图 (Ground.png)</label>
                      <input
                        type="text"
                        value={assetInputs.ground}
                        onChange={(e) => setAssetInputs({ ...assetInputs, ground: e.target.value })}
                        disabled={settings.useProceduralSprites}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-slate-300 text-xs focus:border-cyan-400 outline-none disabled:opacity-40 transition-all font-mono"
                      />
                    </div>

                    {/* Cloud */}
                    <div>
                      <label className="block text-[11px] text-slate-300 mb-1">☁️ 云朵像素图 (Cloud.png)</label>
                      <input
                        type="text"
                        value={assetInputs.cloud}
                        onChange={(e) => setAssetInputs({ ...assetInputs, cloud: e.target.value })}
                        disabled={settings.useProceduralSprites}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-slate-300 text-xs focus:border-cyan-400 outline-none disabled:opacity-40 transition-all font-mono"
                      />
                    </div>

                    {/* Moon */}
                    <div>
                      <label className="block text-[11px] text-slate-300 mb-1">🌙 天体月亮/太阳 (Moon.png)</label>
                      <input
                        type="text"
                        value={assetInputs.moon}
                        onChange={(e) => setAssetInputs({ ...assetInputs, moon: e.target.value })}
                        disabled={settings.useProceduralSprites}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-slate-300 text-xs focus:border-cyan-400 outline-none disabled:opacity-40 transition-all font-mono"
                      />
                    </div>
                  </div>
                </div>

                {/* 3. Cosmetic options & Custom Color customization */}
                <div className="space-y-4 pt-2">
                  <p className="font-semibold text-slate-100 text-[13px] border-b border-slate-800 pb-1.5 flex items-center gap-1.5 font-mono">
                    🦖 8-Bit 英雄角色外观选择 (Skins Select)
                  </p>
                  
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 font-mono">
                    {[
                      { id: 'dino', label: 'T-Rex 恐龙', emoji: '🦖', desc: '经典恐龙主角' },
                      { id: 'kitty', label: '琪琪猫咪', emoji: '🐱', desc: '极速赛博蓝猫' },
                      { id: 'slime', label: '波利黏液', emoji: '🧪', desc: '绿荧弹跳软泥' },
                      { id: 'astro', label: '星际小熊', emoji: '🐻', desc: '呆萌太空憨熊' }
                    ].map((skinItem) => {
                      const active = currentSkinInput === skinItem.id;
                      return (
                        <button
                          key={skinItem.id}
                          type="button"
                          onClick={() => setCurrentSkinInput(skinItem.id as any)}
                          className={`p-2.5 rounded-xl border text-left transition-all relative flex flex-col justify-between h-[82px] select-none cursor-pointer ${
                            active
                              ? 'bg-slate-900 text-white border-cyan-400 shadow-[0_0_12px_rgba(34,211,238,0.25)]'
                              : 'bg-black/40 text-slate-400 border-slate-850 hover:border-slate-800 hover:text-slate-300'
                          }`}
                        >
                          <div className="flex justify-between items-start w-full">
                            <span className="text-xl">{skinItem.emoji}</span>
                            {active && <span className="text-[10px] bg-cyan-400 text-black font-extrabold px-1 rounded">ON</span>}
                          </div>
                          <div>
                            <p className="text-xs font-bold leading-tight">{skinItem.label}</p>
                            <p className="text-[9px] text-slate-500 font-normal leading-tight mt-0.5">{skinItem.desc}</p>
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  {/* Secondary color customization (Only applicable for T-Rex Dino) */}
                  {currentSkinInput === 'dino' && (
                    <div className="space-y-2 pt-1">
                      <p className="text-[11px] font-bold text-slate-300 font-mono">🦖 恐龙专属：皮肤色彩材质定制</p>
                      <div className="flex flex-wrap items-center gap-1.5 font-mono">
                        {[
                          { hex: '#4ade80', name: '春意绿' },
                          { hex: '#38bdf8', name: '天空蓝' },
                          { hex: '#f43f5e', name: '赤焰红' },
                          { hex: '#fbbf24', name: '霓光金' },
                          { hex: '#a855f7', name: '赛博紫' },
                          { hex: '#cbd5e1', name: '极简白' }
                        ].map((col) => {
                          const active = playerColorInput === col.hex;
                          return (
                            <button
                              key={col.hex}
                              type="button"
                              onClick={() => setPlayerColorInput(col.hex)}
                              className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                                active 
                                  ? 'bg-slate-800 text-white border-cyan-400 shadow-[0_0_8px_rgba(56,189,248,0.3)]' 
                                  : 'bg-black/40 text-slate-400 border-slate-810 hover:border-slate-700'
                              }`}
                            >
                              <span className="w-2 h-2 rounded-full block" style={{ backgroundColor: col.hex }} />
                              {col.name}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>

                {/* 4. Cheat Toggles / Advanced fun modes */}
                <div className="space-y-3 pt-2">
                  <p className="font-semibold text-slate-300 text-[13px] border-b border-slate-800 pb-1.5">
                    🕵️ 隐藏极客模式 (Cheats / Fun Options)
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono">
                    <label className="flex items-center justify-between p-2.5 bg-black/40 border border-slate-850 rounded-xl cursor-pointer hover:border-slate-800 select-none">
                      <div className="text-left pr-4">
                        <p className="text-xs font-bold text-slate-200">✨ 无敌神体模式</p>
                        <p className="text-[9px] text-slate-500">免除任何障碍物碰撞检测，刷分作弊专属</p>
                      </div>
                      <input
                        type="checkbox"
                        checked={settings.invincibilityMode}
                        onChange={(e) => updateSettings({ invincibilityMode: e.target.checked })}
                        className="w-4 h-4 accent-cyan-500"
                      />
                    </label>

                    <label className="flex items-center justify-between p-2.5 bg-black/40 border border-slate-850 rounded-xl cursor-pointer hover:border-slate-800 select-none">
                      <div className="text-left pr-4">
                        <p className="text-xs font-bold text-slate-200">🌌 月球轻盈低重力</p>
                        <p className="text-[9px] text-slate-500">巨幅增加跳跃滞空时长，可跨越多堆巨石</p>
                      </div>
                      <input
                        type="checkbox"
                        checked={settings.lowGravityMode}
                        onChange={(e) => updateSettings({ lowGravityMode: e.target.checked })}
                        className="w-4 h-4 accent-cyan-500"
                      />
                    </label>
                  </div>
                </div>

                {/* Sound control sliders */}
                <div className="pt-2 border-t border-slate-800 space-y-3 font-mono">
                  <p className="font-semibold text-slate-300 text-[13px]">🔊 复古合成音量调节</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <div className="flex justify-between mb-1 text-[10px] text-slate-400">
                        <span>跳动/碰撞反馈 (SFX):</span>
                        <span>{Math.round(settings.soundVolume * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.05"
                        value={settings.soundVolume}
                        onChange={(e) => updateSettings({ soundVolume: parseFloat(e.target.value) })}
                        className="w-full accent-emerald-400"
                      />
                    </div>
                    <div>
                      <div className="flex justify-between mb-1 text-[10px] text-slate-400">
                        <span>Background Music (BGM) Vol:</span>
                        <span>{Math.round(settings.musicVolume * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.05"
                        value={settings.musicVolume}
                        onChange={(e) => updateSettings({ musicVolume: parseFloat(e.target.value) })}
                        className="w-full accent-cyan-400"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Form buttons */}
              <div className="bg-slate-950 p-4 border-t border-slate-800/80 flex items-center justify-end gap-3">
                <button
                  id="cancel-settings-btn"
                  onClick={() => setShowSettings(false)}
                  className="px-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 font-bold hover:text-white hover:bg-slate-800 transition-all text-xs"
                >
                  取消
                </button>
                <button
                  id="confirm-settings-btn"
                  onClick={handleSaveSettings}
                  className="px-5 py-2.5 rounded-xl bg-cyan-400 text-black hover:bg-cyan-300 font-bold active:scale-95 transition-all text-xs flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4 stroke-[3px]" /> 确认并保存配置
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
