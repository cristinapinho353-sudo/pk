import { SceneType } from '../types';

// Cache for loaded images
const imageCache: { [url: string]: HTMLImageElement | null } = {};

/**
 * Safely loads or retrieves a cached image from ImageKit or any CDN
 */
export function getLoadedImage(url: string | undefined): HTMLImageElement | null {
  if (!url || url.trim() === '' || url.includes('/xxx/')) {
    return null;
  }
  
  if (imageCache[url] !== undefined) {
    return imageCache[url];
  }

  const img = new Image();
  img.src = url;
  img.crossOrigin = 'anonymous';
  
  // Set placeholder loading state
  imageCache[url] = null;
  
  img.onload = () => {
    imageCache[url] = img;
  };
  
  img.onerror = () => {
    console.error(`Failed to load ImageKit asset: ${url}`);
    imageCache[url] = null; // Don't block future frames, fallback
  };

  return null;
}

/**
 * 1. Draw Dino / Running Player Procedurally
 * Using a 16x16 pixel block representation of a gorgeous T-Rex Dino
 */
const DINO_SPRITE_FRAME_1 = [
  "....######......",
  "....########....",
  "....########....",
  "....##.#####....",
  "....########....",
  "....######......",
  "....#########...",
  "##..######......",
  "######.###......",
  ".#####.#####....",
  "..#########.....",
  "...#######......",
  "....#####.......",
  "....###.##......",
  "....##...#......",
  "....#..........."
];

const DINO_SPRITE_FRAME_2 = [
  "....######......",
  "....########....",
  "....########....",
  "....##.#####....",
  "....########....",
  "....######......",
  "....#########...",
  "##..######......",
  "######.###......",
  ".#####.#####....",
  "..#########.....",
  "...#######......",
  "....#####.......",
  "....##.###......",
  "....#...##......",
  ".........#......"
];

const KITTY_SPRITE_FRAME_1 = [
  ".....#....#.....",
  "....###..###....",
  "....########....",
  "....#.#..#.#....",
  "....########....",
  ".....######.....",
  ".....######..#..",
  "....########.##.",
  "....########.##.",
  "...#########.##.",
  "...#########.##.",
  "....########.##.",
  "....########.#..",
  "....##..##......",
  "....##..##......",
  "....#....#......"
];

const KITTY_SPRITE_FRAME_2 = [
  ".....#....#.....",
  "....###..###....",
  "....########....",
  "....#.#..#.#....",
  "....########....",
  ".....######.....",
  ".....######..##.",
  "....########.##.",
  "....########.#..",
  "...#########....",
  "...#########....",
  "....########....",
  "....########....",
  ".....##..##.....",
  ".....##..##.....",
  "......#...#....."
];

const SLIME_SPRITE_FRAME_1 = [
  "................",
  "................",
  ".......##.......",
  "......####......",
  ".....######.....",
  "....########....",
  "....########....",
  "...##########...",
  "...##..##..##...",
  "...##..##..##...",
  "..############..",
  "..############..",
  ".##############.",
  ".##############.",
  "################",
  "################"
];

const SLIME_SPRITE_FRAME_2 = [
  "................",
  "................",
  "................",
  "................",
  "......####......",
  "....########....",
  "....########....",
  "...##########...",
  "...##..##..##...",
  "..############..",
  "..############..",
  ".##############.",
  "################",
  "################",
  "################",
  "################"
];

const ASTRO_SPRITE_FRAME_1 = [
  "....##....##....",
  "...####..####...",
  "...##########...",
  "...##########...",
  "..###vvvvvv###..",
  "..##vvvvvvvv##..",
  "..##vvvvvvvv##..",
  "..###vvvvvv###..",
  "...##########...",
  "...##########...",
  "....########....",
  "....########....",
  "....########....",
  "....###..###....",
  "....###..###....",
  "....##....##...."
];

const ASTRO_SPRITE_FRAME_2 = [
  "....##....##....",
  "...####..####...",
  "...##########...",
  "...##########...",
  "..###vvvvvv###..",
  "..##vvvvvvvv##..",
  "..##vvvvvvvv##..",
  "..###vvvvvv###..",
  "...##########...",
  "...##########...",
  "....########....",
  "....########....",
  "....########....",
  ".....##..##.....",
  ".....##..##.....",
  "......#...#....."
];

export function drawPixelPlayer(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  size: number,
  frame: number,
  scene: SceneType,
  customColor?: string,
  skin: string = 'dino'
) {
  let sprite = (frame % 10 < 5) ? DINO_SPRITE_FRAME_1 : DINO_SPRITE_FRAME_2;
  if (skin === 'kitty') {
    sprite = (frame % 10 < 5) ? KITTY_SPRITE_FRAME_1 : KITTY_SPRITE_FRAME_2;
  } else if (skin === 'slime') {
    sprite = (frame % 10 < 5) ? SLIME_SPRITE_FRAME_1 : SLIME_SPRITE_FRAME_2;
  } else if (skin === 'astro') {
    sprite = (frame % 10 < 5) ? ASTRO_SPRITE_FRAME_1 : ASTRO_SPRITE_FRAME_2;
  }
  
  const pixelSize = size / 16;
  
  // Determine color theme based on active scene
  let primaryColor = customColor || '#4ade80'; // Emerald default
  let secondaryColor = '#16a34a';
  let eyeColor = '#ffffff';

  if (scene === 'cyber') {
    primaryColor = customColor || '#38bdf8'; // Sky blue neon
    secondaryColor = '#0369a1';
    eyeColor = '#f43f5e'; // pink eye
  } else if (scene === 'lava') {
    primaryColor = customColor || '#f97316'; // Lava orange
    secondaryColor = '#c2410c';
    eyeColor = '#ffff00'; // yellow eye
  } else if (scene === 'classic') {
    primaryColor = customColor || '#e2e8f0'; // Retro white-grey
    secondaryColor = '#94a3b8';
    eyeColor = '#000000';
  }

  // Slime-specific tweaks
  if (skin === 'slime') {
    primaryColor = customColor || (scene === 'lava' ? '#ef4444' : scene === 'cyber' ? '#d946ef' : '#10b981');
    secondaryColor = scene === 'lava' ? '#991b1b' : scene === 'cyber' ? '#86198f' : '#047857';
    eyeColor = '#ffffff';
  }

  // Astro Bear-specific helmet glows
  const visorColor = scene === 'cyber' ? '#d946ef' : '#22d3ee';

  ctx.save();
  for (let r = 0; r < 16; r++) {
    for (let c = 0; c < 16; c++) {
      const char = sprite[r][c];
      if (char === '#') {
        ctx.fillStyle = primaryColor;
        ctx.fillRect(x + c * pixelSize, y + r * pixelSize, pixelSize + 0.3, pixelSize + 0.3);
      } else if (char === '.') {
        // Transparent
      } else if (char === 'v') {
        // Astronaut glass visor
        ctx.fillStyle = visorColor;
        ctx.fillRect(x + c * pixelSize, y + r * pixelSize, pixelSize + 0.3, pixelSize + 0.3);
      } else {
        // Handle shadows or boots / secondary elements
        ctx.fillStyle = secondaryColor;
        ctx.fillRect(x + c * pixelSize, y + r * pixelSize, pixelSize + 0.3, pixelSize + 0.3);
      }
      
      // Draw eye dot specifically at row 3, col 8 (mostly for Dino and Kitty)
      if (skin === 'dino' && r === 3 && c === 8) {
        ctx.fillStyle = eyeColor;
        ctx.fillRect(x + c * pixelSize, y + r * pixelSize, pixelSize, pixelSize);
      } else if (skin === 'kitty' && r === 3 && (c === 5 || c === 9)) {
        ctx.fillStyle = eyeColor;
        ctx.fillRect(x + c * pixelSize, y + r * pixelSize, pixelSize, pixelSize);
      } else if (skin === 'slime' && r === 8 && (c === 4 || c === 10)) {
        ctx.fillStyle = eyeColor;
        ctx.fillRect(x + c * pixelSize, y + r * pixelSize, pixelSize, pixelSize);
      }
    }
  }
  ctx.restore();
}

/**
 * 2. Draw Retro Obstacles (Cactus, Spikes or Lava Columns)
 */
export function drawPixelObstacle(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  scene: SceneType
) {
  ctx.save();
  if (scene === 'cyber') {
    // Cyber Synthwave Glowing spikes
    ctx.strokeStyle = '#f43f5e';
    ctx.lineWidth = 3;
    ctx.fillStyle = '#881337';
    
    // Draw neon triangle spear
    ctx.beginPath();
    ctx.moveTo(x, y + height);
    ctx.lineTo(x + width / 2, y);
    ctx.lineTo(x + width, y + height);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    
    // Laser core Glow lines
    ctx.strokeStyle = '#fda4af';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x + width / 2, y + 4);
    ctx.lineTo(x + width / 2, y + height - 2);
    ctx.stroke();

  } else if (scene === 'lava') {
    // Volcanic Brimstone Pillar
    ctx.fillStyle = '#450a0a'; // Dark obsidian volcanic rock
    ctx.fillRect(x, y, width, height);

    // Draw hot lava cracks running through rock
    ctx.fillStyle = '#ea580c';
    ctx.fillRect(x + width * 0.3, y, width * 0.15, height);
    ctx.fillRect(x + width * 0.1, y + height * 0.4, width * 0.4, 4);
    ctx.fillRect(x + width * 0.5, y + height * 0.7, width * 0.4, 4);

    // Golden sparks at top
    ctx.fillStyle = '#eab308';
    ctx.fillRect(x, y, width, 4);
  } else if (scene === 'grass') {
    // Classic Pixel Cactus (Green with prickly needles)
    ctx.fillStyle = '#22c55e'; // Bright green
    ctx.fillRect(x + width * 0.3, y, width * 0.4, height); // Main trunk
    
    // Cactus side branch 1
    ctx.fillRect(x, y + height * 0.3, width * 0.3, width * 0.35); // branch arm
    ctx.fillRect(x, y + height * 0.1, width * 0.3, height * 0.2); // finger up

    // Cactus side branch 2 (higher)
    ctx.fillRect(x + width * 0.7, y + height * 0.4, width * 0.3, width * 0.35); 
    ctx.fillRect(x + width * 0.7, y + height * 0.2, width * 0.3, height * 0.22);

    // Cactus shades
    ctx.fillStyle = '#15803d'; // Dark forest green details
    ctx.fillRect(x + width * 0.45, y + 4, width * 0.1, height - 8);
    // Draw black/dark mini spikes
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(x + width * 0.15, y + height * 0.25, 2, 2);
    ctx.fillRect(x + width * 0.8, y + height * 0.35, 2, 2);
    ctx.fillRect(x + width * 0.48, y + height * 0.6, 2, 2);
  } else {
    // Classic gameboy stone blocks or block tower
    ctx.fillStyle = '#cbd5e1'; // Grey light stone
    ctx.fillRect(x, y, width, height);
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, width, height);
    
    // Grid bricks lines
    ctx.fillStyle = '#64748b';
    ctx.fillRect(x, y + height/3, width, 2);
    ctx.fillRect(x, y + (2*height)/3, width, 2);
    ctx.fillRect(x + width/2, y, 2, height/3);
    ctx.fillRect(x + width/3, y + height/3, 2, height/3);
    ctx.fillRect(x + (2*width)/3, y + (2*height)/3, 2, height/3);
  }
  ctx.restore();
}

/**
 * 3. Draw Beautiful Pixel Ground
 */
export function drawPixelGround(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  groundY: number,
  scrollX: number,
  scene: SceneType
) {
  ctx.save();
  
  if (scene === 'cyber') {
    // Cyber Grid Ground
    ctx.fillStyle = '#0f0022';
    ctx.fillRect(0, groundY, width, height);

    // Neon purple scanline grid top margin
    ctx.fillStyle = '#a855f7';
    ctx.fillRect(0, groundY, width, 4);
    
    // Perspective grid line simulation
    ctx.strokeStyle = 'rgba(168, 85, 247, 0.4)';
    ctx.lineWidth = 2;
    
    // Vertical grid ticks scrolling backwards
    const tickInterval = 60;
    const offset = scrollX % tickInterval;
    for (let xOffset = -tickInterval; xOffset < width + tickInterval; xOffset += tickInterval) {
      const xPos = xOffset - offset;
      ctx.beginPath();
      ctx.moveTo(xPos, groundY);
      ctx.lineTo(xPos - 30, groundY + height);
      ctx.stroke();
    }
    
    // Horizontal perspective lines
    ctx.beginPath();
    ctx.moveTo(0, groundY + 12);
    ctx.lineTo(width, groundY + 12);
    ctx.moveTo(0, groundY + 28);
    ctx.lineTo(width, groundY + 28);
    ctx.stroke();

  } else if (scene === 'lava') {
    // Molten lava cracked surface
    ctx.fillStyle = '#1e0505'; // very dark brown
    ctx.fillRect(0, groundY, width, height);
    
    // Top magma crust
    ctx.fillStyle = '#b91c1c'; // volcano red crust
    ctx.fillRect(0, groundY, width, 5);

    // Dynamic lava cracks scrolling
    ctx.fillStyle = '#f97316'; // orange glowing magma inside cracks
    const step = 45;
    const offset = scrollX % step;
    for (let i = -step; i < width + step; i += step) {
      const blockX = i - offset;
      ctx.fillRect(blockX, groundY + 5, 8, height);
      ctx.fillRect(blockX, groundY + 12, 18, 5);
    }
  } else if (scene === 'grass') {
    // Classic warm field (bright Grass + earthy layers)
    // Soil deep layer
    ctx.fillStyle = '#78350f'; // wood rich brown soil
    ctx.fillRect(0, groundY, width, height);
    
    // Middle dirt detail blocks
    ctx.fillStyle = '#451a03';
    const tileWidth = 30;
    const tileOffset = scrollX % tileWidth;
    for (let x = -tileWidth; x < width + tileWidth; x += tileWidth) {
      ctx.fillRect(x - tileOffset + 5, groundY + 12, 8, 4);
      ctx.fillRect(x - tileOffset + 18, groundY + 20, 6, 4);
    }

    // Top grass layer
    ctx.fillStyle = '#4ade80'; // bright green grass
    ctx.fillRect(0, groundY, width, 6);
    
    // Grass pixel drops
    ctx.fillStyle = '#22c55e'; // darker green tufts
    for (let x = -tileWidth; x < width + tileWidth; x += 15) {
      ctx.fillRect(x - tileOffset, groundY + 6, 3, 4);
      ctx.fillRect(x - tileOffset + 8, groundY + 6, 2, 6);
    }
  } else {
    // Slate/classic monochromatic retro
    ctx.fillStyle = '#1e293b'; // dark slate
    ctx.fillRect(0, groundY, width, height);

    ctx.fillStyle = '#64748b'; // slate divider top
    ctx.fillRect(0, groundY, width, 4);

    // Dotted floor tiles
    ctx.fillStyle = '#334155';
    const dotInterval = 20;
    const offset = scrollX % dotInterval;
    for (let x = -dotInterval; x < width + dotInterval; x += dotInterval) {
      ctx.fillRect(x - offset + 2, groundY + 8, 2, 2);
      ctx.fillRect(x - offset + 12, groundY + 18, 2, 2);
    }
  }
  ctx.restore();
}

/**
 * 4. Draw Fluffy Pixel Clouds
 */
export function drawPixelCloud(ctx: CanvasRenderingContext2D, x: number, y: number, size: number) {
  ctx.save();
  ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
  
  // Custom rectangular pixel layout
  // Cloud core: horizontal rectangle
  ctx.fillRect(x, y + size * 0.3, size, size * 0.4);
  // Layer tops
  ctx.fillRect(x + size * 0.2, y + size * 0.1, size * 0.6, size * 0.3);
  ctx.fillRect(x + size * 0.35, y, size * 0.3, size * 0.2);
  // Layer fluff sides
  ctx.fillRect(x - size * 0.1, y + size * 0.4, size * 1.1, size * 0.2);
  
  // High contrast white highlight lines (to pop the cloud structure)
  ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
  ctx.fillRect(x + size * 0.2, y + size * 0.1, size * 0.3, size * 0.1);
  ctx.fillRect(x + size * 0.35, y, size * 0.15, size * 0.1);
  ctx.restore();
}

/**
 * 5. Draw Glowing Celestial Elements (Moon / Purple Neon Sun)
 */
export function drawPixelMoon(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  size: number,
  scene: SceneType
) {
  ctx.save();
  
  if (scene === 'cyber') {
    // Retro Cyber Synthwave Grid Sun with Horizontal bars
    const radius = size / 2;
    const centerY = y + radius;
    const centerX = x + radius;

    // Outer Neon Orange-Pink gradient sun glow
    const grad = ctx.createLinearGradient(centerX, y, centerX, y + size);
    grad.addColorStop(0, '#f43f5e'); // Rose intense
    grad.addColorStop(1, '#eab308'); // Sunset yellow
    
    ctx.fillStyle = grad;
    
    // Draw slices bypassing cuts
    for (let sliceY = 0; sliceY < size; sliceY += 4) {
      // Horizontal bar check: exclude specific cutlines at the lower half of the sun
      if (sliceY > size * 0.4 && sliceY % 8 >= 5) {
        continue; // skip drawing to create scanline cuts
      }
      
      const distFromCenter = Math.abs(sliceY - radius);
      const halfWidth = Math.sqrt(radius * radius - distFromCenter * distFromCenter);
      
      if (halfWidth > 0) {
        ctx.fillRect(centerX - halfWidth, y + sliceY, halfWidth * 2, 3);
      }
    }
  } else {
    // Beautiful Classic / Sunset crescent moon
    const isGrass = scene === 'grass';
    ctx.fillStyle = isGrass ? '#fef08a' : '#cbd5e1'; // warm yellow vs silver gray
    
    // Outer circle
    ctx.beginPath();
    ctx.arc(x + size/2, y + size/2, size/2, 0, Math.PI * 2);
    ctx.fill();
    
    // Darker crater spots
    ctx.fillStyle = isGrass ? '#facc15' : '#94a3b8';
    ctx.fillRect(x + size * 0.3, y + size * 0.25, size * 0.15, size * 0.15);
    ctx.fillRect(x + size * 0.55, y + size * 0.45, size * 0.2, size * 0.2);
    ctx.fillRect(x + size * 0.25, y + size * 0.6, size * 0.1, size * 0.1);
  }
  ctx.restore();
}

/**
 * 6. Draw Layered Mountains / Far Hills
 */
export function drawPixelHill(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  scene: SceneType
) {
  ctx.save();
  
  if (scene === 'cyber') {
    // Cyber neon geometric grid mountain
    ctx.strokeStyle = '#8b5cf6'; // Violet boundary
    ctx.fillStyle = '#1e1b4b'; // Deep dark violet base
    ctx.lineWidth = 2;
    
    ctx.beginPath();
    ctx.moveTo(x, y + height);
    ctx.lineTo(x + width * 0.5, y);
    ctx.lineTo(x + width, y + height);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Geometric grid details inside mountain
    ctx.strokeStyle = 'rgba(139, 92, 246, 0.4)';
    ctx.beginPath();
    ctx.moveTo(x + width * 0.25, y + height * 0.5);
    ctx.lineTo(x + width * 0.5, y + height);
    ctx.moveTo(x + width * 0.75, y + height * 0.5);
    ctx.lineTo(x + width * 0.5, y + height);
    ctx.stroke();

  } else if (scene === 'lava') {
    // Molten volcanic mountains
    ctx.fillStyle = '#450a0a'; // Dark volcanic ash brown
    ctx.beginPath();
    ctx.moveTo(x, y + height);
    ctx.lineTo(x + width * 0.3, y + height * 0.25);
    ctx.lineTo(x + width * 0.5, y); // peak
    ctx.lineTo(x + width * 0.7, y + height * 0.4);
    ctx.lineTo(x + width, y + height);
    ctx.closePath();
    ctx.fill();
    
    // Molten glowing crests
    ctx.fillStyle = '#dc2626';
    ctx.fillRect(x + width * 0.46, y, width * 0.08, height * 0.1);
    
  } else if (scene === 'grass') {
    // Beautiful tiered soft green hills
    ctx.fillStyle = '#166534'; // Forest green hill
    ctx.beginPath();
    ctx.moveTo(x, y + height);
    ctx.bezierCurveTo(x + width * 0.25, y, x + width * 0.75, y, x + width, y + height);
    ctx.closePath();
    ctx.fill();
    
    // Pine trees silhouettes in blocky pixel style
    ctx.fillStyle = '#14532d'; // Darkest forest green
    ctx.fillRect(x + width * 0.3, y + height * 0.4, 6, height * 0.6); // trunk
    ctx.fillRect(x + width * 0.3 - 6, y + height * 0.4 - 10, 18, 12); // leaves banner
    ctx.fillRect(x + width * 0.3 - 3, y + height * 0.4 - 20, 12, 10);
  } else {
    // Classic monochromatic slate peaks
    ctx.fillStyle = '#334155'; // Darker grey-blue
    ctx.beginPath();
    ctx.moveTo(x, y + height);
    ctx.lineTo(x + width * 0.5, y);
    ctx.lineTo(x + width, y + height);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
}
