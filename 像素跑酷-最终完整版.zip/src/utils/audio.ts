// Web Audio API 8-Bit Retro Sound Effects Synthesizer

let audioCtx: AudioContext | null = null;
let bgmInterval: NodeJS.Timeout | null = null;
let bgmOsc: OscillatorNode | null = null;
let bgmGain: GainNode | null = null;
let currentBgmStep = 0;

function getAudioCtx(): AudioContext {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

// 1. Play Jump sound effect (Fast rising frequency)
export function playJumpSound(volume: number) {
  try {
    const ctx = getAudioCtx();
    const now = ctx.currentTime;
    
    // Create nodes
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    // Retro feel: Square or Triangle wave
    osc.type = 'triangle';
    
    // Pitch sweeps from 150Hz to 600Hz in 0.15s
    osc.frequency.setValueAtTime(150, now);
    osc.frequency.exponentialRampToValueAtTime(650, now + 0.15);
    
    // Volume envelope
    gain.gain.setValueAtTime(volume * 0.4, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.15);
    
    osc.start(now);
    osc.stop(now + 0.16);
  } catch (e) {
    console.warn('Audio synthesis failed:', e);
  }
}

// 2. Play Crash/Hit sound (Low pitch with descending noise-like drop)
export function playHitSound(volume: number) {
  try {
    const ctx = getAudioCtx();
    const now = ctx.currentTime;
    
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(ctx.destination);
    
    osc1.type = 'sawtooth';
    osc1.frequency.setValueAtTime(120, now);
    osc1.frequency.linearRampToValueAtTime(30, now + 0.4);
    
    osc2.type = 'square';
    osc2.frequency.setValueAtTime(90, now);
    osc2.frequency.linearRampToValueAtTime(10, now + 0.4);
    
    gain.gain.setValueAtTime(volume * 0.6, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.5);
    
    osc1.start(now);
    osc2.start(now);
    
    osc1.stop(now + 0.5);
    osc2.stop(now + 0.5);
  } catch (e) {
    console.warn('Audio synthesis failed:', e);
  }
}

// 3. Play Score up/Active sound (Classic double beep combo)
export function playScoreSound(volume: number) {
  try {
    const ctx = getAudioCtx();
    const now = ctx.currentTime;
    
    // First high note (E5 - 659.25 Hz)
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    
    osc1.type = 'square';
    osc1.frequency.setValueAtTime(659.25, now);
    gain1.gain.setValueAtTime(volume * 0.25, now);
    gain1.gain.exponentialRampToValueAtTime(0.01, now + 0.08);
    
    osc1.start(now);
    osc1.stop(now + 0.09);
    
    // Second higher note (B5 - 987.77 Hz) slightly delayed
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    
    osc2.type = 'square';
    osc2.frequency.setValueAtTime(987.77, now + 0.08);
    gain2.gain.setValueAtTime(0, now);
    gain2.gain.setValueAtTime(volume * 0.25, now + 0.08);
    gain2.gain.exponentialRampToValueAtTime(0.01, now + 0.22);
    
    osc2.start(now + 0.08);
    osc2.stop(now + 0.23);
  } catch (e) {
    console.warn('Audio synthesis failed:', e);
  }
}

// 4. Procedural 8-bit dynamic Background Music
// A simple chord progression & retro baseline
const CHORDS_NOTES = [
  [130.81, 261.63, 329.63, 392.00], // C major baselines
  [146.83, 293.66, 349.23, 440.00], // D minor
  [164.81, 329.63, 392.00, 493.88], // E minor
  [174.61, 349.23, 440.00, 523.25]  // F major
];

export function startBgm(volume: number) {
  if (bgmInterval) {
    clearInterval(bgmInterval);
    bgmInterval = null;
  }
  
  try {
    const ctx = getAudioCtx();
    
    currentBgmStep = 0;
    
    // Play a step every 200ms (120 BPM 16th notes/8th notes rhythm)
    bgmInterval = setInterval(() => {
      try {
        const now = ctx.currentTime;
        const chordIndex = Math.floor(currentBgmStep / 8) % CHORDS_NOTES.length;
        const chord = CHORDS_NOTES[chordIndex];
        
        // Base note
        let noteFrequency = chord[0]; // Bass
        
        // Melodic styling
        const subStep = currentBgmStep % 8;
        if (subStep === 2 || subStep === 6) {
          noteFrequency = chord[2]; // Third
        } else if (subStep === 4) {
          noteFrequency = chord[3]; // Fifth
        } else if (subStep === 7) {
          noteFrequency = chord[1] * 1.5; // High chord scale
        }
        
        // Create retro synth pulse
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        
        osc.connect(gain);
        gain.connect(ctx.destination);
        
        // Switch wave type based on step to keep rhythm fun
        osc.type = subStep % 2 === 0 ? 'triangle' : 'square';
        osc.frequency.setValueAtTime(noteFrequency, now);
        
        // Low pulse volume
        const adjustedVol = volume * (subStep === 0 ? 0.15 : 0.08);
        gain.gain.setValueAtTime(adjustedVol, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
        
        osc.start(now);
        osc.stop(now + 0.19);
        
        currentBgmStep++;
      } catch (innerError) {
        // Safe catch
      }
    }, 220);
    
  } catch (e) {
    console.warn('Failed to start BGM Synthesizer:', e);
  }
}

export function stopBgm() {
  if (bgmInterval) {
    clearInterval(bgmInterval);
    bgmInterval = null;
  }
}
