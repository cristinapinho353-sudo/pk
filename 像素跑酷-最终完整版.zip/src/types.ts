export type SceneType = 'classic' | 'cyber' | 'grass' | 'lava';

export type GameState = 'menu' | 'playing' | 'gameover';

export type PlayerSkinType = 'dino' | 'kitty' | 'slime' | 'astro';

export interface AssetUrls {
  player: string;
  obstacle: string;
  ground: string;
  cloud: string;
  moon: string;
  hill: string;
}

export interface Obstacle {
  x: number;
  y: number;
  width: number;
  height: number;
  type: 'cactus' | 'birds' | 'spikes';
  speedMultiplier: number;
  passed: boolean;
  frame?: number;
}

export interface Collectible {
  id: number;
  x: number;
  y: number;
  width: number;
  height: number;
  type: 'coin' | 'shield' | 'chili';
  pulseFrame: number;
  collected: boolean;
  value: number;
}

export interface FloatingText {
  id: number;
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
  scale: number;
  vy: number;
  life: number;
}

export interface Decoration {
  id: number;
  x: number;
  y: number;
  type: 'cloud' | 'moon' | 'hill' | 'star' | 'neon-column';
  size: number;
  speedScale: number;
  color?: string;
  w?: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  decay: number;
  shape?: 'square' | 'circle' | 'sparkle' | 'bubble';
}

export interface GameSettings {
  soundVolume: number; // 0 to 1
  musicVolume: number; // 0 to 1
  enableBgm: boolean;
  customAssets: AssetUrls;
  playerColor: string;
  currentSkin: PlayerSkinType;
  useProceduralSprites: boolean;
  invincibilityMode: boolean; // secret cheat
  lowGravityMode: boolean; // secret cheat
}

export interface ScoreHistory {
  date: string;
  score: number;
  scene: SceneType;
  duration: number; // in seconds
}
